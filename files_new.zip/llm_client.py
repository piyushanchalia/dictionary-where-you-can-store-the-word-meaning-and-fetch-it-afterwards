"""
llm_client.py — Shared Azure OpenAI client used by every agent.
All agents call ask() with a system prompt + user message and get a string back.
For structured output, ask_json() parses and returns a dict.
"""

import json
import logging
from openai import AzureOpenAI

from config import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_API_VERSION,
    AZURE_DEPLOYMENT_NAME,
)

logger = logging.getLogger(__name__)

_client = AzureOpenAI(
    api_key        = AZURE_OPENAI_API_KEY,
    azure_endpoint = AZURE_OPENAI_ENDPOINT,
    api_version    = AZURE_OPENAI_API_VERSION,
)


def ask(system: str, user: str, max_tokens: int = 800, temperature: float = 0.3) -> str:
    """
    Send a single-turn message to Azure GPT.
    Returns the model's reply as a plain string.
    """
    try:
        response = _client.chat.completions.create(
            model       = AZURE_DEPLOYMENT_NAME,
            max_tokens  = max_tokens,
            temperature = temperature,
            messages    = [
                {"role": "system", "content": system},
                {"role": "user",   "content": user},
            ],
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        logger.error(f"Azure OpenAI call failed: {e}")
        raise


def ask_json(system: str, user: str, max_tokens: int = 800) -> dict:
    """
    Like ask(), but instructs the model to reply with pure JSON
    and returns a parsed dict. Strips markdown fences if present.
    """
    system_json = system + "\n\nIMPORTANT: Reply with ONLY valid JSON. No markdown, no extra text."
    raw = ask(system_json, user, max_tokens=max_tokens, temperature=0.1)
    # Strip ```json ... ``` fences
    if raw.startswith("```"):
        parts = raw.split("```")
        raw = parts[1].lstrip("json").strip() if len(parts) > 1 else raw
    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        logger.error(f"JSON parse failed: {e}\nRaw: {raw[:300]}")
        return {}
