"""
agent_risk.py — Agent 4: Risk & Sentiment Analyst
Responsibility: Evaluate beta, profit growth, valuation, and market
mood to assign a risk/sentiment score (0–100) per symbol.
Also applies hard filters and flags any stock that should be excluded.
"""

from base_agent import BaseAgent
from config import MAX_DEBT_EQUITY, MAX_BETA, MIN_AVG_VOLUME


class RiskSentimentAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="RiskSentimentAgent",
            role="Score beta, momentum, valuation, apply hard filters — flag risky stocks"
        )

    def run(self, data: dict) -> dict:
        """
        data: DataAgent payload {symbol: {"price": df, "fundamentals": dict}}
        Returns per-symbol sentiment scores and a filtered list.
        """
        report  = self._base_report()
        results = {}
        filtered_out = {}

        for symbol, payload in data.items():
            fund = payload["fundamentals"]
            df   = payload["price"]

            # Hard filter first
            fail_reason = self._hard_filter(fund, df)
            if fail_reason:
                filtered_out[symbol] = fail_reason
                continue

            try:
                score, detail = self._score(fund)
                results[symbol] = {"score": score, "signals": detail}
            except Exception as e:
                self.logger.warning(f"  Risk score failed for {symbol}: {e}")
                results[symbol] = {"score": 0.0, "signals": {}}

        ranked = sorted(results.items(), key=lambda x: x[1]["score"], reverse=True)
        top10  = [(s, v["score"]) for s, v in ranked[:10]]

        report.update({
            "results":        results,
            "filtered_out":   filtered_out,
            "top10":          top10,
            "passed_count":   len(results),
            "filtered_count": len(filtered_out),
            "summary": (
                f"{len(results)} symbols passed risk filters, "
                f"{len(filtered_out)} excluded. "
                f"Top sentiment: {top10[0][0]} ({top10[0][1]:.1f}/100)."
                if top10 else f"No symbols passed. {len(filtered_out)} excluded."
            )
        })
        self.logger.info(report["summary"])
        return report

    def _hard_filter(self, fund: dict, df) -> str | None:
        """Returns a reason string if stock should be excluded, else None."""
        de   = fund.get("debt_to_equity")
        beta = fund.get("beta")

        if de is not None and de > MAX_DEBT_EQUITY:
            return f"D/E {de:.1f} exceeds {MAX_DEBT_EQUITY} limit"
        if beta is not None and beta > MAX_BETA:
            return f"Beta {beta:.1f} exceeds {MAX_BETA} — too volatile for swing"

        # Liquidity check via average volume from price data
        try:
            avg_vol = float(df["Volume"].squeeze().tail(20).mean())
            if avg_vol < MIN_AVG_VOLUME:
                return f"Avg volume {avg_vol:,.0f} below {MIN_AVG_VOLUME:,} — illiquid"
        except Exception:
            pass

        return None

    def _score(self, fund: dict) -> tuple[float, dict]:
        score  = 0.0
        detail = {}

        # Beta — prefer moderate for swing trades
        beta = fund.get("beta")
        if beta is not None:
            if 0.8 <= beta <= 1.4:  pts = 35; lbl = f"Beta {beta:.2f} — ideal swing range"
            elif beta < 0.8:        pts = 20; lbl = f"Beta {beta:.2f} — low vol"
            else:                   pts = 15; lbl = f"Beta {beta:.2f} — elevated"
        else:
            pts = 18; lbl = "Beta not available (neutral)"
        score += pts; detail["beta"] = f"{lbl} (+{pts})"

        # Profit growth momentum
        pg = fund.get("profit_growth")
        if pg is not None:
            if pg >= 20:   pts = 40; lbl = f"Profit growth {pg:.1f}% — strong"
            elif pg >= 5:  pts = 25; lbl = f"Profit growth {pg:.1f}% — positive"
            elif pg >= 0:  pts = 10; lbl = f"Profit growth {pg:.1f}% — flat"
            else:          pts = 0;  lbl = f"Profit growth {pg:.1f}% — declining"
        else:
            pts = 15; lbl = "Profit growth not available (neutral)"
        score += pts; detail["profit_growth"] = f"{lbl} (+{pts})"

        # Valuation
        pe = fund.get("pe_ratio")
        if pe is not None and pe > 0:
            if pe <= 20:   pts = 25; lbl = f"PE {pe:.1f} — value"
            elif pe <= 40: pts = 15; lbl = f"PE {pe:.1f} — fair"
            elif pe <= 70: pts = 5;  lbl = f"PE {pe:.1f} — expensive"
            else:          pts = 0;  lbl = f"PE {pe:.1f} — very expensive"
        else:
            pts = 10; lbl = "PE not available (neutral)"
        score += pts; detail["valuation"] = f"{lbl} (+{pts})"

        return min(score, 100.0), detail
