"""
config.py — Central configuration for the Multi-Agent Swing Trade System
"""

# ─── Azure OpenAI ────────────────────────────────────────────────────────────
AZURE_OPENAI_API_KEY      = "YOUR_AZURE_OPENAI_KEY"
AZURE_OPENAI_ENDPOINT     = "https://YOUR_RESOURCE.openai.azure.com/"
AZURE_OPENAI_API_VERSION  = "2024-02-01"
AZURE_DEPLOYMENT_NAME     = "gpt-4o"          # your deployed model name

# ─── Universe ────────────────────────────────────────────────────────────────
NIFTY50_SYMBOLS = [
    "RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK",
    "HINDUNILVR", "ITC", "SBIN", "BHARTIARTL", "BAJFINANCE",
    "KOTAKBANK", "LT", "ASIANPAINT", "AXISBANK", "MARUTI",
    "SUNPHARMA", "TITAN", "ULTRACEMCO", "WIPRO", "NESTLEIND",
    "POWERGRID", "NTPC", "TECHM", "HCLTECH", "ONGC",
    "M&M", "BAJAJFINSV", "TATAMOTORS", "COALINDIA", "ADANIENT",
    "JSWSTEEL", "TATASTEEL", "GRASIM", "DRREDDY", "DIVISLAB",
    "CIPLA", "HINDALCO", "BPCL", "EICHERMOT", "INDUSINDBK",
    "HEROMOTOCO", "APOLLOHOSP", "TATACONSUM", "BRITANNIA",
    "SBILIFE", "HDFCLIFE", "ADANIPORTS", "UPL", "VEDL", "SHREECEM"
]

MIDCAP_SYMBOLS = [
    "ALOKINDS", "ASHOKLEY", "AUROPHARMA", "BALKRISIND", "BEL",
    "BERGEPAINT", "CANBK", "CHOLAFIN", "CONCOR", "COROMANDEL",
    "CROMPTON", "CUMMINSIND", "DALBHARAT", "EMAMILTD", "GMRINFRA",
    "GODREJPROP", "IDFCFIRSTB", "INDUSTOWER", "IRCTC", "JINDALSTEL",
    "JUBLFOOD", "KANSAINER", "LICHSGFIN", "LUPIN", "MFSL",
    "MOTHERSON", "MUTHOOTFIN", "NMDC", "OFSS", "PAGEIND",
    "PEL", "PERSISTENT", "PFC", "PIDILITIND", "PNB",
    "RBLBANK", "RECLTD", "SAIL", "SRF", "TORNTPHARM",
    "TRENT", "TVSMOTOR", "UNIONBANK", "VOLTAS", "ZYDUSLIFE"
]

SMALLCAP_SYMBOLS = [
    "MAHSEAMLS", "BALRAMCHIN", "RAIN", "IFCI", "RVNL",
    "RAILVIKAS", "IRFC", "SJVN", "NHPC", "HUDCO"
]

ALL_SYMBOLS = NIFTY50_SYMBOLS + MIDCAP_SYMBOLS + SMALLCAP_SYMBOLS

# ─── Technical parameters ────────────────────────────────────────────────────
RSI_PERIOD         = 14
RSI_OVERSOLD       = 40
RSI_OVERBOUGHT     = 70
MACD_FAST          = 12
MACD_SLOW          = 26
MACD_SIGNAL        = 9
EMA_SHORT          = 20
EMA_LONG           = 50
EMA_TREND          = 200
ATR_PERIOD         = 14
VOLUME_SURGE_MULT  = 1.5
LOOKBACK_DAYS      = 90

# ─── Fundamental thresholds ──────────────────────────────────────────────────
MAX_DEBT_EQUITY    = 1.5
MIN_ROE            = 10
MIN_INTEREST_COV   = 2.0
MIN_PROMOTER_HOLD  = 30

# ─── Risk & trade parameters ─────────────────────────────────────────────────
MIN_RISK_REWARD    = 2.0
STOPLOSS_ATR_MULT  = 1.5
MAX_STOCKS_PER_DAY = 7
MAX_BETA           = 1.8
MIN_AVG_VOLUME     = 200_000

# ─── Schedule ────────────────────────────────────────────────────────────────
ALERT_TIME         = "09:10"     # HH:MM IST, Mon–Fri

# ─── Data source ─────────────────────────────────────────────────────────────
DATA_SOURCE        = "yfinance"  # "yfinance" or "kite"
KITE_API_KEY       = ""
KITE_ACCESS_TOKEN  = ""
