"""
agent_technical.py — Agent 2: Technical Analyst
Responsibility: Compute RSI, MACD, EMA, ATR, breakout, volume signals
for every symbol and score each 0–100. Reports a ranked technical list.
"""

import numpy as np
import pandas as pd

from base_agent import BaseAgent
from config import (
    RSI_PERIOD, RSI_OVERSOLD, RSI_OVERBOUGHT,
    MACD_FAST, MACD_SLOW, MACD_SIGNAL,
    EMA_SHORT, EMA_LONG, EMA_TREND,
    ATR_PERIOD, VOLUME_SURGE_MULT, MAX_DEBT_EQUITY, MAX_BETA
)


class TechnicalAnalystAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="TechnicalAnalystAgent",
            role="Scan price/volume data — RSI, MACD, EMA, breakout, ATR — score 0-100"
        )

    def run(self, data: dict) -> dict:
        """
        data: output payload from DataAgent
              {symbol: {"price": df, "fundamentals": dict}}
        Returns report with per-symbol technical scores and signals.
        """
        report  = self._base_report()
        results = {}

        for symbol, payload in data.items():
            df = payload["price"]
            try:
                score, detail = self._score(df)
                results[symbol] = {"score": score, "signals": detail}
            except Exception as e:
                self.logger.warning(f"  Technical score failed for {symbol}: {e}")
                results[symbol] = {"score": 0.0, "signals": {}}

        # Rank and summarise
        ranked = sorted(results.items(), key=lambda x: x[1]["score"], reverse=True)
        top10  = [(s, v["score"]) for s, v in ranked[:10]]

        report.update({
            "results": results,
            "top10":   top10,
            "summary": (
                f"Scored {len(results)} symbols technically. "
                f"Top pick: {top10[0][0]} ({top10[0][1]:.1f}/100)."
                if top10 else "No symbols scored."
            )
        })
        self.logger.info(report["summary"])
        return report

    # ── Indicators ───────────────────────────────────────────────────────────

    def _score(self, df: pd.DataFrame) -> tuple[float, dict]:
        close  = df["Close"].squeeze()
        volume = df["Volume"].squeeze()

        rsi                     = self._rsi(close)
        macd, signal, hist      = self._macd(close)
        ema20, ema50, ema200    = self._emas(close)
        atr                     = self._atr(df)

        last_rsi    = float(rsi.iloc[-1])
        last_hist   = float(hist.iloc[-1])
        prev_hist   = float(hist.iloc[-2]) if len(hist) > 1 else 0.0
        last_macd   = float(macd.iloc[-1])
        last_signal = float(signal.iloc[-1])
        last_close  = float(close.iloc[-1])
        last_ema20  = float(ema20.iloc[-1])
        last_ema50  = float(ema50.iloc[-1])
        last_ema200 = float(ema200.iloc[-1])
        last_atr    = float(atr.iloc[-1])
        vol_ratio   = self._volume_ratio(volume)
        breakout    = self._breakout(df)
        support_bnc = self._support_bounce(df)

        score  = 0.0
        detail = {}

        # RSI
        if RSI_OVERSOLD <= last_rsi <= 60:
            pts = 20; lbl = f"{last_rsi:.1f} — swing buy zone"
        elif last_rsi < RSI_OVERSOLD:
            pts = 12; lbl = f"{last_rsi:.1f} — oversold"
        else:
            pts = 0;  lbl = f"{last_rsi:.1f} — overbought"
        score += pts; detail["rsi"] = f"{lbl} (+{pts})"

        # MACD
        if last_macd > last_signal and last_hist > prev_hist:
            pts = 20; lbl = "Bullish crossover, histogram rising"
        elif last_hist > prev_hist:
            pts = 10; lbl = "Histogram turning up"
        else:
            pts = 0;  lbl = "No bullish MACD signal"
        score += pts; detail["macd"] = f"{lbl} (+{pts})"

        # EMA structure
        ema_pts, ema_notes = 0, []
        if last_close > last_ema20:  ema_pts += 7;  ema_notes.append("above EMA20")
        if last_close > last_ema50:  ema_pts += 8;  ema_notes.append("above EMA50")
        if last_close > last_ema200: ema_pts += 10; ema_notes.append("above EMA200")
        score += ema_pts
        detail["ema"] = f"{', '.join(ema_notes) or 'below all EMAs'} (+{ema_pts})"

        # Breakout / support
        if breakout:
            pts = 20; lbl = "Breaking 20-day high"
        elif support_bnc:
            pts = 10; lbl = "Bouncing off support"
        else:
            pts = 0;  lbl = "No breakout/support signal"
        score += pts; detail["breakout"] = f"{lbl} (+{pts})"

        # Volume
        if vol_ratio >= VOLUME_SURGE_MULT:
            pts = 15; lbl = f"{vol_ratio:.1f}x avg — surge"
        elif vol_ratio >= 1.2:
            pts = 7;  lbl = f"{vol_ratio:.1f}x avg — above avg"
        else:
            pts = 0;  lbl = f"{vol_ratio:.1f}x avg — low"
        score += pts; detail["volume"] = f"{lbl} (+{pts})"

        # Store raw values for trade-level computation
        detail.update({
            "atr":        round(last_atr, 2),
            "last_close": round(last_close, 2),
            "ema20":      round(last_ema20, 2),
            "ema50":      round(last_ema50, 2),
            "ema200":     round(last_ema200, 2),
        })

        return min(score, 100.0), detail

    # ── Math helpers ─────────────────────────────────────────────────────────

    def _rsi(self, close: pd.Series) -> pd.Series:
        delta = close.diff()
        gain  = delta.clip(lower=0).ewm(com=RSI_PERIOD - 1, min_periods=RSI_PERIOD).mean()
        loss  = (-delta).clip(lower=0).ewm(com=RSI_PERIOD - 1, min_periods=RSI_PERIOD).mean()
        rs    = gain / loss.replace(0, np.nan)
        return 100 - (100 / (1 + rs))

    def _macd(self, close: pd.Series):
        fast   = close.ewm(span=MACD_FAST,   adjust=False).mean()
        slow   = close.ewm(span=MACD_SLOW,   adjust=False).mean()
        line   = fast - slow
        sig    = line.ewm(span=MACD_SIGNAL,  adjust=False).mean()
        return line, sig, line - sig

    def _emas(self, close: pd.Series):
        return (
            close.ewm(span=EMA_SHORT,  adjust=False).mean(),
            close.ewm(span=EMA_LONG,   adjust=False).mean(),
            close.ewm(span=EMA_TREND,  adjust=False).mean(),
        )

    def _atr(self, df: pd.DataFrame) -> pd.Series:
        h, l, c = df["High"].squeeze(), df["Low"].squeeze(), df["Close"].squeeze()
        tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
        return tr.ewm(span=ATR_PERIOD, adjust=False).mean()

    def _volume_ratio(self, volume: pd.Series, window: int = 20) -> float:
        if len(volume) < window + 1:
            return 1.0
        avg = volume.iloc[-(window + 1):-1].mean()
        return float(volume.iloc[-1] / avg) if avg > 0 else 1.0

    def _breakout(self, df: pd.DataFrame, lookback: int = 20) -> bool:
        if len(df) < lookback + 1:
            return False
        return float(df["Close"].iloc[-1]) > float(df["High"].iloc[-(lookback + 1):-1].max())

    def _support_bounce(self, df: pd.DataFrame, lookback: int = 20) -> bool:
        if len(df) < lookback + 1:
            return False
        prev_low = float(df["Low"].iloc[-(lookback + 1):-1].min())
        return float(df["Close"].iloc[-1]) <= prev_low * 1.02
