"""
agent_orchestrator.py — The Orchestrating Agent (The Human Analyst)

This is the brain of the system. It:
  1. Receives reports from all 4 specialist agents
  2. Merges scores into a composite ranking
  3. Calls Azure GPT to reason like a senior analyst —
     reviewing each candidate and DECIDING which stocks to pick,
     why, and what the trade card should look like
  4. Returns final, human-quality trade cards

The GPT prompt is designed so the model acts as an experienced
Indian equity fund manager who has just received research from
his technical, fundamental, and risk teams.
"""

import json
import logging
from datetime import date, datetime

from base_agent import BaseAgent
from llm_client import ask_json, ask
from config import MAX_STOCKS_PER_DAY, MIN_RISK_REWARD, STOPLOSS_ATR_MULT, NIFTY50_SYMBOLS, MIDCAP_SYMBOLS

logger = logging.getLogger("OrchestratorAgent")


ORCHESTRATOR_SYSTEM = """
You are a senior Indian equity fund manager with 20 years of experience in NSE/BSE swing trading.

Your research team has submitted reports from three specialist analysts:
  - Technical Analyst: price action, momentum, breakout signals
  - Fundamental Analyst: balance sheet, profitability, debt health
  - Risk Analyst: volatility, sentiment, valuation, hard filters

Your job is to act like a human portfolio manager reviewing this research and
making the final INVESTMENT DECISION. You are NOT a scoring algorithm — you
think holistically, weigh trade-offs, and decide which stocks genuinely deserve
capital based on the next 2–10 day swing trade horizon.

Rules you follow:
1. Pick only stocks where the risk:reward is attractive (minimum 1:2)
2. Never pick more than 2 stocks from the same sector
3. Prefer stocks where multiple signals converge (technical + fundamental both strong)
4. If the overall market (Nifty) is weak, be more conservative — pick fewer, safer stocks
5. Explain your reasoning in plain English like you're briefing a junior analyst
6. Be specific — cite actual numbers, not generic phrases
7. Output ONLY valid JSON — no extra text, no markdown
"""

DECISION_SCHEMA = """{
  "market_view": "Brief view on Nifty/market mood for today",
  "total_picks": <number 1-7>,
  "picks": [
    {
      "rank":            1,
      "symbol":          "TICKER",
      "company_name":    "Full name",
      "sector":          "Sector",
      "cap_type":        "Large / Mid / Small",
      "entry_price":     <number>,
      "stoploss":        <number>,
      "target_price":    <number>,
      "expected_return": <percent as number>,
      "risk_reward":     "1:2.0",
      "holding_days":    "e.g. 3-5 days",
      "why_pick":        "2-3 sentences citing specific signals and numbers",
      "key_strength":    "single strongest factor",
      "key_risk":        "single biggest risk",
      "catalyst":        "what could trigger the move",
      "exit_strategy":   "how and when to exit",
      "confidence":      "High / Medium / Low",
      "tech_score":      <number>,
      "fund_score":      <number>,
      "risk_score":      <number>,
      "composite_score": <number>
    }
  ],
  "stocks_rejected": [
    {"symbol": "X", "reason": "why not picked despite high score"}
  ],
  "analyst_note": "Overall note from you as the portfolio manager"
}"""


class OrchestratorAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="OrchestratorAgent",
            role="Collect all agent reports, reason as a human analyst, make final picks"
        )

    def run(self, agent_reports: dict) -> dict:
        """
        agent_reports: {
            "data":        DataAgent report,
            "technical":   TechnicalAnalystAgent report,
            "fundamental": FundamentalAnalystAgent report,
            "risk":        RiskSentimentAgent report,
        }
        Returns final trade cards with full GPT reasoning.
        """
        report = self._base_report()
        self.logger.info("Orchestrator starting — merging all agent reports …")

        # Step 1: Merge scores and build a candidate universe
        candidates = self._merge_scores(agent_reports)
        self.logger.info(f"  {len(candidates)} candidates after merging agent reports")

        if not candidates:
            report.update({
                "status": "no_candidates",
                "picks":  [],
                "summary": "No stocks passed all agent filters today.",
            })
            return report

        # Step 2: Compute trade levels for each candidate
        candidates = self._compute_trade_levels(candidates, agent_reports["technical"]["results"])

        # Step 3: Build a rich briefing for GPT and ask it to decide
        self.logger.info("  Sending candidate briefing to GPT for final decision …")
        briefing  = self._build_briefing(candidates, agent_reports)
        decision  = self._ask_gpt_to_decide(briefing)

        if not decision or "picks" not in decision:
            self.logger.error("GPT decision failed — falling back to rule-based picks")
            decision = self._fallback_decision(candidates)

        # Step 4: Package final output
        picks = decision.get("picks", [])
        report.update({
            "date":           date.today().isoformat(),
            "market_view":    decision.get("market_view", "N/A"),
            "analyst_note":   decision.get("analyst_note", ""),
            "picks":          picks,
            "stocks_rejected": decision.get("stocks_rejected", []),
            "total_picks":    len(picks),
            "candidates_reviewed": len(candidates),
            "summary": (
                f"Orchestrator selected {len(picks)} stocks from "
                f"{len(candidates)} candidates. "
                f"Market view: {decision.get('market_view', 'N/A')[:80]}"
            )
        })
        self.logger.info(report["summary"])
        return report

    # ── Score merger ──────────────────────────────────────────────────────────

    def _merge_scores(self, agent_reports: dict) -> list[dict]:
        """
        Intersect all three analyst results (only symbols that passed
        the risk hard filter get through) and compute composite score.
        """
        tech_results  = agent_reports.get("technical", {}).get("results", {})
        fund_results  = agent_reports.get("fundamental", {}).get("results", {})
        risk_results  = agent_reports.get("risk", {}).get("results", {})
        data_payload  = agent_reports.get("data", {}).get("payload", {})

        # Only keep symbols that PASSED the risk filter
        safe_symbols  = set(risk_results.keys())

        candidates = []
        for sym in safe_symbols:
            t = tech_results.get(sym, {})
            f = fund_results.get(sym, {})
            r = risk_results.get(sym, {})
            d = data_payload.get(sym, {}).get("fundamentals", {})

            t_score = t.get("score", 0.0)
            f_score = f.get("score", 0.0)
            r_score = r.get("score", 0.0)

            composite = round(t_score * 0.50 + f_score * 0.30 + r_score * 0.20, 1)

            candidates.append({
                "symbol":       sym,
                "company_name": d.get("company_name", sym),
                "sector":       d.get("sector") or "Unknown",
                "cap_type":     self._cap_type(sym),
                "tech_score":   round(t_score, 1),
                "fund_score":   round(f_score, 1),
                "risk_score":   round(r_score, 1),
                "composite":    composite,
                "tech_signals": t.get("signals", {}),
                "fund_signals": f.get("signals", {}),
                "risk_signals": r.get("signals", {}),
                "fundamentals": d,
            })

        # Sort by composite, take top 20 to send to GPT (token budget)
        candidates.sort(key=lambda x: x["composite"], reverse=True)
        return candidates[:20]

    # ── Trade level computation ───────────────────────────────────────────────

    def _compute_trade_levels(self, candidates: list[dict], tech_results: dict) -> list[dict]:
        """Add entry, SL, target to each candidate using ATR from tech agent."""
        for c in candidates:
            td = tech_results.get(c["symbol"], {}).get("signals", {})
            close = td.get("last_close", 0.0)
            atr   = td.get("atr", 0.0)

            c["last_close"] = close

            if close > 0 and atr > 0:
                sl_dist = round(atr * STOPLOSS_ATR_MULT, 2)
                entry   = round(close, 2)
                sl      = round(entry - sl_dist, 2)
                target  = round(entry + sl_dist * MIN_RISK_REWARD, 2)
                ret_pct = round((target - entry) / entry * 100, 2)

                c.update({
                    "entry":           entry,
                    "stoploss":        sl,
                    "target":          target,
                    "expected_return": ret_pct,
                    "atr":             round(atr, 2),
                })
            else:
                c.update({"entry": 0, "stoploss": 0, "target": 0,
                          "expected_return": 0, "atr": 0})
        return candidates

    # ── GPT briefing ─────────────────────────────────────────────────────────

    def _build_briefing(self, candidates: list[dict], agent_reports: dict) -> str:
        risk_report  = agent_reports.get("risk", {})
        filtered_out = risk_report.get("filtered_out", {})

        lines = [
            f"Today's date: {date.today().strftime('%A, %d %B %Y')}",
            f"Total symbols scanned: {len(agent_reports.get('data', {}).get('payload', {}))}",
            f"Stocks filtered out by risk agent: {len(filtered_out)}",
            f"Candidates forwarded for review: {len(candidates)}",
            "",
            "=== CANDIDATE STOCKS (sorted by composite score) ===",
        ]

        for i, c in enumerate(candidates, 1):
            f = c["fundamentals"]
            ts = c["tech_signals"]
            lines.append(f"""
--- Candidate {i}: {c['company_name']} ({c['symbol']}) | {c['cap_type']} Cap | {c['sector']} ---
Composite score : {c['composite']}/100  (Tech:{c['tech_score']} | Fund:{c['fund_score']} | Risk:{c['risk_score']})
Trade levels    : Entry ₹{c['entry']} | SL ₹{c['stoploss']} | Target ₹{c['target']} | Return {c['expected_return']}%
Fundamentals    : D/E={f.get('debt_to_equity','N/A')} | ROE={f.get('roe','N/A')}% | PE={f.get('pe_ratio','N/A')} | Beta={f.get('beta','N/A')}
Revenue growth  : {f.get('revenue_growth','N/A')}% | Profit growth: {f.get('profit_growth','N/A')}%
Technical       : RSI={ts.get('rsi','N/A')} | MACD={ts.get('macd','N/A')} | EMA={ts.get('ema','N/A')}
Volume/Breakout : {ts.get('volume','N/A')} | {ts.get('breakout','N/A')}
ATR             : {c['atr']}""")

        lines.append(f"""
=== STOCKS REJECTED BY RISK AGENT (sample) ===
{chr(10).join([f"  {s}: {r}" for s, r in list(filtered_out.items())[:10]])}

=== YOUR TASK ===
As the portfolio manager, review the {len(candidates)} candidates above.
Select the BEST {min(MAX_STOCKS_PER_DAY, len(candidates))} stocks for swing trades over the next 2-10 days.
Apply your judgment — scores are inputs, not the final word.
For each pick, finalize the entry, stoploss, and target (you may adjust
the computed levels if you think they are off based on the chart context).

Respond with the JSON schema provided.
""")
        return "\n".join(lines)

    def _ask_gpt_to_decide(self, briefing: str) -> dict:
        user_prompt = briefing + f"\n\nJSON schema to follow:\n{DECISION_SCHEMA}"
        try:
            return ask_json(
                system    = ORCHESTRATOR_SYSTEM,
                user      = user_prompt,
                max_tokens= 3000,
            )
        except Exception as e:
            logger.error(f"GPT decision call failed: {e}")
            return {}

    # ── Fallback (no GPT) ────────────────────────────────────────────────────

    def _fallback_decision(self, candidates: list[dict]) -> dict:
        """Rule-based fallback: take top N by composite score with sector diversity."""
        sector_count = {}
        picks = []
        for c in candidates:
            if len(picks) >= MAX_STOCKS_PER_DAY:
                break
            sector = c["sector"]
            if sector_count.get(sector, 0) >= 2:
                continue
            sector_count[sector] = sector_count.get(sector, 0) + 1
            picks.append({
                "rank":            len(picks) + 1,
                "symbol":          c["symbol"],
                "company_name":    c["company_name"],
                "sector":          c["sector"],
                "cap_type":        c["cap_type"],
                "entry_price":     c["entry"],
                "stoploss":        c["stoploss"],
                "target_price":    c["target"],
                "expected_return": c["expected_return"],
                "risk_reward":     f"1:{MIN_RISK_REWARD}",
                "holding_days":    "4-7 days",
                "why_pick":        f"Composite score {c['composite']}/100 with multi-signal confirmation.",
                "key_strength":    "Strong composite signal alignment",
                "key_risk":        "Market-wide weakness could impact all picks",
                "catalyst":        "Technical momentum + fundamental support",
                "exit_strategy":   f"Exit at target ₹{c['target']} or SL ₹{c['stoploss']}.",
                "confidence":      "High" if c["composite"] >= 70 else "Medium",
                "tech_score":      c["tech_score"],
                "fund_score":      c["fund_score"],
                "risk_score":      c["risk_score"],
                "composite_score": c["composite"],
            })

        return {
            "market_view":    "Unable to assess — using rule-based fallback",
            "picks":          picks,
            "stocks_rejected": [],
            "analyst_note":   "GPT unavailable. Fallback rule-based selection used.",
        }

    @staticmethod
    def _cap_type(symbol: str) -> str:
        if symbol in NIFTY50_SYMBOLS: return "Large"
        if symbol in MIDCAP_SYMBOLS:  return "Mid"
        return "Small"
