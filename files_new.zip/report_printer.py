"""
report_printer.py — Format and print the orchestrator's final picks to console.
Also saves a JSON log for performance tracking.
No Telegram, no external dependencies beyond standard library.
"""

import json
import logging
from datetime import date, datetime
from pathlib import Path

logger = logging.getLogger("ReportPrinter")
LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)


def print_report(orchestrator_report: dict):
    """Print the full daily report to console and save JSON log."""
    picks        = orchestrator_report.get("picks", [])
    market_view  = orchestrator_report.get("market_view", "N/A")
    analyst_note = orchestrator_report.get("analyst_note", "")
    rejected     = orchestrator_report.get("stocks_rejected", [])
    reviewed     = orchestrator_report.get("candidates_reviewed", "?")

    today = date.today().strftime("%A, %d %B %Y")
    W = 62

    # ── Header ────────────────────────────────────────────────────────────────
    print(f"\n{'═' * W}")
    print(f"  SWING TRADE PICKS — {today}")
    print(f"  {len(picks)} picks | {reviewed} candidates reviewed | 9:15 AM IST")
    print(f"{'═' * W}")

    # ── Market view ──────────────────────────────────────────────────────────
    print(f"\n📊 MARKET VIEW (Portfolio Manager)\n  {market_view}\n")

    if not picks:
        print("  ⚠️  No stocks selected today. Market conditions unfavourable.")
        _save_json(orchestrator_report)
        return

    # ── Individual picks ──────────────────────────────────────────────────────
    for pick in picks:
        conf_icon = {"High": "🟢", "Medium": "🟡", "Low": "🔴"}.get(
                     pick.get("confidence", ""), "⚪")
        cap_label = f"{pick.get('cap_type', '')} Cap"

        print(f"{'─' * W}")
        print(f" PICK #{pick.get('rank', '?')}  {pick.get('company_name', '')} "
              f"({pick.get('symbol', '')})  |  {cap_label}  |  {pick.get('sector', '')}")
        print(f"{'─' * W}")
        print(f"  💰 Entry        :  ₹{pick.get('entry_price', 'N/A')}")
        print(f"  🛑 Stoploss     :  ₹{pick.get('stoploss', 'N/A')}")
        print(f"  🎯 Target       :  ₹{pick.get('target_price', 'N/A')}")
        print(f"  📈 Return       :  {pick.get('expected_return', 'N/A')}%  "
              f"in {pick.get('holding_days', 'N/A')}")
        print(f"  ⚖️  Risk:Reward  :  {pick.get('risk_reward', 'N/A')}")
        print(f"  {conf_icon} Confidence  :  {pick.get('confidence', 'N/A')}")
        print()
        print(f"  📝 Why pick this?")
        _wrap_print(pick.get("why_pick", "N/A"), indent=5, width=W - 5)
        print()
        print(f"  ✅ Key strength  :  {pick.get('key_strength', 'N/A')}")
        print(f"  ⚠️  Key risk      :  {pick.get('key_risk', 'N/A')}")
        print(f"  🔮 Catalyst      :  {pick.get('catalyst', 'N/A')}")
        print(f"  🚪 Exit strategy :  {pick.get('exit_strategy', 'N/A')}")
        print()
        print(f"  Scores → Tech:{pick.get('tech_score','?')} | "
              f"Fund:{pick.get('fund_score','?')} | "
              f"Risk:{pick.get('risk_score','?')} | "
              f"Composite:{pick.get('composite_score','?')}/100")
        print()

    # ── Rejected stocks ───────────────────────────────────────────────────────
    if rejected:
        print(f"{'─' * W}")
        print(f"  Stocks considered but rejected by portfolio manager:")
        for r in rejected:
            print(f"    ✗  {r.get('symbol', '?')}  —  {r.get('reason', '')}")
        print()

    # ── Analyst note ─────────────────────────────────────────────────────────
    if analyst_note:
        print(f"{'─' * W}")
        print("  📌 Portfolio Manager's Note:")
        _wrap_print(analyst_note, indent=5, width=W - 5)
        print()

    print(f"{'═' * W}\n")

    # ── Save JSON log ─────────────────────────────────────────────────────────
    _save_json(orchestrator_report)


def _wrap_print(text: str, indent: int = 4, width: int = 56):
    """Simple word-wrap for console output."""
    words  = str(text).split()
    line   = " " * indent
    for word in words:
        if len(line) + len(word) + 1 > width:
            print(line)
            line = " " * indent + word
        else:
            line = line + (" " if line.strip() else "") + word
    if line.strip():
        print(line)


def _save_json(report: dict):
    today    = date.today().isoformat()
    log_path = LOG_DIR / f"picks_{today}.json"
    with open(log_path, "w") as f:
        json.dump(report, f, indent=2, default=str)
    logger.info(f"Report saved → {log_path}")
    print(f"  📁 Full report saved to logs/picks_{today}.json\n")
