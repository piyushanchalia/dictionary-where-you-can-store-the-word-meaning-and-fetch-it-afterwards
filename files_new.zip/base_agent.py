"""
base_agent.py — Base class for all agents in the system.

Every agent has:
  - name        : display name shown in logs and orchestrator reports
  - role        : one-line description of its job
  - run(data)   : the main method each agent implements
  - report      : the structured dict it returns to the orchestrator

The orchestrator collects all reports and makes the final decision.
"""

import logging
from abc import ABC, abstractmethod
from datetime import datetime


class BaseAgent(ABC):
    def __init__(self, name: str, role: str):
        self.name   = name
        self.role   = role
        self.logger = logging.getLogger(name)

    @abstractmethod
    def run(self, data: dict) -> dict:
        """
        Execute the agent's analysis on the provided data.

        data  : whatever the agent needs (price df, fundamentals, etc.)
        return: a structured dict — the agent's "report" to the orchestrator.
                Must always include:
                  {
                    "agent":     self.name,
                    "role":      self.role,
                    "timestamp": ISO string,
                    "status":    "ok" | "error",
                    ...          agent-specific fields
                  }
        """

    def _base_report(self, status: str = "ok") -> dict:
        return {
            "agent":     self.name,
            "role":      self.role,
            "timestamp": datetime.now().isoformat(),
            "status":    status,
        }

    def __repr__(self):
        return f"<Agent: {self.name}>"
