"""
agent_data.py — Agent 1: Data Collector
Responsibility: Fetch price (OHLCV) and fundamental data for all symbols.
Reports a clean data payload to the orchestrator.
"""

import logging
from datetime import datetime, timedelta
from typing import Optional

import pandas as pd
import yfinance as yf

from base_agent import BaseAgent
from config import ALL_SYMBOLS, DATA_SOURCE, LOOKBACK_DAYS

logger = logging.getLogger("DataAgent")


class DataAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="DataAgent",
            role="Fetch OHLCV price history and fundamental ratios for all symbols"
        )

    def run(self, data: dict = None) -> dict:
        """
        Fetches data for all configured symbols.
        Returns report with 'payload' key containing
        {symbol: {"price": df, "fundamentals": dict}}.
        """
        self.logger.info(f"Starting data collection for {len(ALL_SYMBOLS)} symbols …")
        report = self._base_report()

        payload    = {}
        failed     = []

        for sym in ALL_SYMBOLS:
            try:
                df   = self._fetch_price(sym)
                if df is None or len(df) < 30:
                    failed.append(sym)
                    continue
                fund = self._fetch_fundamentals(sym)
                payload[sym] = {"price": df, "fundamentals": fund}
            except Exception as e:
                logger.warning(f"  {sym}: {e}")
                failed.append(sym)

        report.update({
            "symbols_fetched": len(payload),
            "symbols_failed":  len(failed),
            "failed_list":     failed[:10],   # first 10 for brevity
            "payload":         payload,
            "summary": (
                f"Fetched data for {len(payload)} symbols. "
                f"{len(failed)} failed (no data or delisted)."
            )
        })
        self.logger.info(report["summary"])
        return report

    # ── Private helpers ───────────────────────────────────────────────────────

    def _fetch_price(self, symbol: str) -> Optional[pd.DataFrame]:
        ticker = f"{symbol}.NS"
        end    = datetime.today()
        start  = end - timedelta(days=LOOKBACK_DAYS + 15)
        df = yf.download(ticker, start=start, end=end, progress=False, auto_adjust=True)
        if df.empty:
            return None
        df = df[["Open", "High", "Low", "Close", "Volume"]].dropna()
        df.index = pd.to_datetime(df.index)
        return df.tail(LOOKBACK_DAYS)

    def _fetch_fundamentals(self, symbol: str) -> dict:
        defaults = {
            "debt_to_equity": None, "roe": None,
            "interest_coverage": None, "promoter_holding": None,
            "revenue_growth": None,  "profit_growth": None,
            "pe_ratio": None, "market_cap": None,
            "beta": None, "sector": None, "company_name": symbol,
        }
        try:
            info = yf.Ticker(f"{symbol}.NS").info
            ie   = info.get("interestExpense")
            eb   = info.get("ebitda")
            defaults.update({
                "debt_to_equity":    info.get("debtToEquity"),
                "roe":               self._pct(info.get("returnOnEquity")),
                "interest_coverage": round(abs(eb / ie), 2) if eb and ie else None,
                "revenue_growth":    self._pct(info.get("revenueGrowth")),
                "profit_growth":     self._pct(info.get("earningsGrowth")),
                "pe_ratio":          info.get("trailingPE"),
                "market_cap":        info.get("marketCap"),
                "beta":              info.get("beta"),
                "sector":            info.get("sector"),
                "company_name":      info.get("longName", symbol),
            })
        except Exception:
            pass
        return defaults

    @staticmethod
    def _pct(val) -> Optional[float]:
        if val is None:
            return None
        return round(float(val) * 100, 2)
