"""
agent_fundamental.py — Agent 3: Fundamental Analyst
Responsibility: Evaluate debt, ROE, coverage, growth, valuation for every
symbol and score each 0–100. Reports findings to the orchestrator.
"""

from base_agent import BaseAgent
from config import MAX_DEBT_EQUITY, MIN_ROE, MIN_INTEREST_COV, MIN_PROMOTER_HOLD


class FundamentalAnalystAgent(BaseAgent):
    def __init__(self):
        super().__init__(
            name="FundamentalAnalystAgent",
            role="Evaluate D/E, ROE, interest coverage, growth, valuation — score 0-100"
        )

    def run(self, data: dict) -> dict:
        """
        data: DataAgent payload {symbol: {"price": df, "fundamentals": dict}}
        Returns per-symbol fundamental scores.
        """
        report  = self._base_report()
        results = {}

        for symbol, payload in data.items():
            fund = payload["fundamentals"]
            try:
                score, detail = self._score(fund)
                results[symbol] = {"score": score, "signals": detail, "fundamentals": fund}
            except Exception as e:
                self.logger.warning(f"  Fundamental score failed for {symbol}: {e}")
                results[symbol] = {"score": 0.0, "signals": {}, "fundamentals": fund}

        ranked = sorted(results.items(), key=lambda x: x[1]["score"], reverse=True)
        top10  = [(s, v["score"]) for s, v in ranked[:10]]

        report.update({
            "results": results,
            "top10":   top10,
            "summary": (
                f"Scored {len(results)} symbols fundamentally. "
                f"Top: {top10[0][0]} ({top10[0][1]:.1f}/100)." if top10 else "No symbols."
            )
        })
        self.logger.info(report["summary"])
        return report

    def _score(self, fund: dict) -> tuple[float, dict]:
        score  = 0.0
        detail = {}

        # Debt-to-Equity
        de = fund.get("debt_to_equity")
        if de is not None:
            if de <= 0:     pts = 30; lbl = "Debt-free / net cash"
            elif de <= 0.5: pts = 25; lbl = f"D/E {de:.2f} — very low"
            elif de <= MAX_DEBT_EQUITY: pts = 15; lbl = f"D/E {de:.2f} — acceptable"
            else:           pts = 0;  lbl = f"D/E {de:.2f} — high (filtered)"
        else:
            pts = 10; lbl = "D/E not available (neutral)"
        score += pts; detail["debt_equity"] = f"{lbl} (+{pts})"

        # ROE
        roe = fund.get("roe")
        if roe is not None:
            if roe >= 20:      pts = 25; lbl = f"ROE {roe:.1f}% — excellent"
            elif roe >= MIN_ROE: pts = 15; lbl = f"ROE {roe:.1f}% — healthy"
            elif roe >= 0:     pts = 5;  lbl = f"ROE {roe:.1f}% — low"
            else:              pts = 0;  lbl = f"ROE {roe:.1f}% — negative"
        else:
            pts = 8; lbl = "ROE not available (neutral)"
        score += pts; detail["roe"] = f"{lbl} (+{pts})"

        # Interest coverage
        ic = fund.get("interest_coverage")
        if ic is not None:
            if ic >= 5:   pts = 20; lbl = f"Coverage {ic:.1f}x — very strong"
            elif ic >= MIN_INTEREST_COV: pts = 12; lbl = f"Coverage {ic:.1f}x — adequate"
            else:         pts = 0;  lbl = f"Coverage {ic:.1f}x — weak"
        else:
            pts = 8; lbl = "Coverage not available (neutral)"
        score += pts; detail["interest_coverage"] = f"{lbl} (+{pts})"

        # Revenue growth
        rg = fund.get("revenue_growth")
        if rg is not None:
            if rg >= 15:  pts = 15; lbl = f"Revenue growth {rg:.1f}% — strong"
            elif rg >= 5: pts = 8;  lbl = f"Revenue growth {rg:.1f}% — moderate"
            else:         pts = 0;  lbl = f"Revenue growth {rg:.1f}% — weak/negative"
        else:
            pts = 5; lbl = "Revenue growth not available (neutral)"
        score += pts; detail["revenue_growth"] = f"{lbl} (+{pts})"

        # Promoter holding
        ph = fund.get("promoter_holding")
        if ph is not None:
            if ph >= 50:  pts = 10; lbl = f"Promoter {ph:.1f}% — high conviction"
            elif ph >= MIN_PROMOTER_HOLD: pts = 5; lbl = f"Promoter {ph:.1f}% — adequate"
            else:         pts = 0;  lbl = f"Promoter {ph:.1f}% — low"
        else:
            pts = 3; lbl = "Promoter holding not available (neutral)"
        score += pts; detail["promoter_holding"] = f"{lbl} (+{pts})"

        return min(score, 100.0), detail
