"""
main.py — Multi-Agent Swing Trade System Entry Point

Runs 4 specialist agents in sequence, then the Orchestrator (GPT) 
makes the final human-quality decision.

Usage:
  python main.py              # Start daily scheduler (9:10 AM, Mon-Fri)
  python main.py --now        # Run pipeline immediately
  python main.py --symbols RELIANCE TCS INFY  # Run for specific symbols only
"""

import argparse
import logging
import sys
import time
from datetime import datetime
from pathlib import Path

import schedule

from config import ALERT_TIME, ALL_SYMBOLS

# ── Logging ──────────────────────────────────────────────────────────────────
Path("logs").mkdir(exist_ok=True)

logging.basicConfig(
    level   = logging.INFO,
    format  = "%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/swing_trader.log", mode="a"),
    ]
)
logger = logging.getLogger("Main")


# ── Pipeline ─────────────────────────────────────────────────────────────────

def run_pipeline(symbols: list[str] = None):
    """
    Full multi-agent pipeline:

      Agent 1  DataAgent              — fetch price + fundamentals
         ↓
      Agent 2  TechnicalAnalystAgent  — RSI, MACD, EMA, breakout, volume
      Agent 3  FundamentalAnalystAgent— D/E, ROE, coverage, growth
      Agent 4  RiskSentimentAgent     — beta, momentum, hard filters
         ↓
      Agent 5  OrchestratorAgent      — GPT reasons like a human PM → final picks
         ↓
      ReportPrinter                  — console output + JSON log
    """
    from agent_data         import DataAgent
    from agent_technical    import TechnicalAnalystAgent
    from agent_fundamental  import FundamentalAnalystAgent
    from agent_risk         import RiskSentimentAgent
    from agent_orchestrator import OrchestratorAgent
    from report_printer     import print_report

    t0       = datetime.now()
    symbols  = symbols or ALL_SYMBOLS

    logger.info("=" * 65)
    logger.info(f"  MULTI-AGENT PIPELINE STARTED — {t0.strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"  Universe: {len(symbols)} symbols")
    logger.info("=" * 65)

    # ── Agent 1: Data ─────────────────────────────────────────────────────────
    logger.info("[Agent 1/5] DataAgent — fetching market data …")
    data_agent  = DataAgent()

    # Temporarily restrict to the passed symbol list
    import config as cfg
    _orig = cfg.ALL_SYMBOLS
    cfg.ALL_SYMBOLS = symbols
    data_report = data_agent.run()
    cfg.ALL_SYMBOLS = _orig

    if not data_report.get("payload"):
        logger.error("DataAgent returned no data — aborting.")
        return

    payload = data_report["payload"]
    logger.info(f"  → {len(payload)} symbols with data")

    # ── Agent 2: Technical ────────────────────────────────────────────────────
    logger.info("[Agent 2/5] TechnicalAnalystAgent — computing indicators …")
    tech_report = TechnicalAnalystAgent().run(payload)
    logger.info(f"  → Top 3 technical: {tech_report['top10'][:3]}")

    # ── Agent 3: Fundamental ──────────────────────────────────────────────────
    logger.info("[Agent 3/5] FundamentalAnalystAgent — evaluating balance sheets …")
    fund_report = FundamentalAnalystAgent().run(payload)
    logger.info(f"  → Top 3 fundamental: {fund_report['top10'][:3]}")

    # ── Agent 4: Risk / Sentiment ─────────────────────────────────────────────
    logger.info("[Agent 4/5] RiskSentimentAgent — filtering and scoring risk …")
    risk_report = RiskSentimentAgent().run(payload)
    logger.info(f"  → {risk_report['passed_count']} passed | {risk_report['filtered_count']} filtered out")

    # ── Agent 5: Orchestrator (GPT) ───────────────────────────────────────────
    logger.info("[Agent 5/5] OrchestratorAgent — GPT making final decision …")
    orchestrator = OrchestratorAgent()
    final_report = orchestrator.run({
        "data":        data_report,
        "technical":   tech_report,
        "fundamental": fund_report,
        "risk":        risk_report,
    })

    # ── Print + save ──────────────────────────────────────────────────────────
    print_report(final_report)

    elapsed = round((datetime.now() - t0).total_seconds(), 1)
    logger.info(f"Pipeline complete in {elapsed}s — {final_report.get('total_picks', 0)} picks")


# ── Scheduler ─────────────────────────────────────────────────────────────────

def start_scheduler():
    logger.info(f"Scheduler started — running pipeline at {ALERT_TIME} IST, Mon–Fri")
    logger.info("Press Ctrl+C to stop.")

    for day in [schedule.every().monday, schedule.every().tuesday,
                schedule.every().wednesday, schedule.every().thursday,
                schedule.every().friday]:
        day.at(ALERT_TIME).do(run_pipeline)

    while True:
        schedule.run_pending()
        time.sleep(30)


# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Multi-Agent Swing Trade System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py                          # Start daily scheduler
  python main.py --now                    # Run once immediately
  python main.py --symbols RELIANCE TCS   # Run for specific stocks
        """
    )
    parser.add_argument("--now",     action="store_true",
                        help="Run pipeline immediately instead of scheduling")
    parser.add_argument("--symbols", nargs="+", metavar="SYM",
                        help="Run for specific symbols (e.g. RELIANCE TCS HDFCBANK)")
    args = parser.parse_args()

    if args.now or args.symbols:
        run_pipeline(args.symbols)
    else:
        start_scheduler()


if __name__ == "__main__":
    main()
