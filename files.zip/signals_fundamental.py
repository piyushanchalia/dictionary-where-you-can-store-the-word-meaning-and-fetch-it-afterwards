"""
signals_fundamental.py — Layer 2b & 2c: Fundamental + sentiment scoring
Produces a 0–100 score for each, which feeds the composite scorer.
"""

import logging

from config import (
    MAX_DEBT_EQUITY, MIN_ROE, MIN_INTEREST_COV, MIN_PROMOTER_HOLD
)

logger = logging.getLogger(__name__)


# ─── Fundamental score ───────────────────────────────────────────────────────

def fundamental_score(fund: dict) -> tuple[float, dict]:
    """
    Returns (score 0–100, detail_dict).
    Rewards low debt, high ROE, good coverage, and promoter confidence.
    """
    score  = 0.0
    detail = {}

    # Debt-to-Equity
    de = fund.get("debt_to_equity")
    if de is not None:
        if de <= 0:
            pts = 30; label = "debt-free or net cash"
        elif de <= 0.5:
            pts = 25; label = f"D/E {de:.2f} — very low"
        elif de <= MAX_DEBT_EQUITY:
            pts = 15; label = f"D/E {de:.2f} — acceptable"
        else:
            pts = 0;  label = f"D/E {de:.2f} — high debt (penalty)"
        score += pts
        detail["debt_equity"] = f"{label} (+{pts})"
    else:
        detail["debt_equity"] = "D/E not available (0)"

    # ROE
    roe = fund.get("roe")
    if roe is not None:
        if roe >= 20:
            pts = 25; label = f"ROE {roe:.1f}% — excellent"
        elif roe >= MIN_ROE:
            pts = 15; label = f"ROE {roe:.1f}% — healthy"
        elif roe >= 0:
            pts = 5;  label = f"ROE {roe:.1f}% — low"
        else:
            pts = 0;  label = f"ROE {roe:.1f}% — negative"
        score += pts
        detail["roe"] = f"{label} (+{pts})"
    else:
        detail["roe"] = "ROE not available (0)"

    # Interest coverage
    ic = fund.get("interest_coverage")
    if ic is not None:
        if ic >= 5:
            pts = 20; label = f"Coverage {ic:.1f}x — very strong"
        elif ic >= MIN_INTEREST_COV:
            pts = 12; label = f"Coverage {ic:.1f}x — adequate"
        else:
            pts = 0;  label = f"Coverage {ic:.1f}x — weak"
        score += pts
        detail["interest_coverage"] = f"{label} (+{pts})"
    else:
        detail["interest_coverage"] = "Interest coverage not available (0)"

    # Revenue growth
    rev_g = fund.get("revenue_growth")
    if rev_g is not None:
        if rev_g >= 15:
            pts = 15; label = f"Revenue growth {rev_g:.1f}% — strong"
        elif rev_g >= 5:
            pts = 8;  label = f"Revenue growth {rev_g:.1f}% — moderate"
        else:
            pts = 0;  label = f"Revenue growth {rev_g:.1f}% — weak"
        score += pts
        detail["revenue_growth"] = f"{label} (+{pts})"
    else:
        detail["revenue_growth"] = "Revenue growth not available (0)"

    # Promoter holding
    ph = fund.get("promoter_holding")
    if ph is not None:
        if ph >= 50:
            pts = 10; label = f"Promoter holding {ph:.1f}% — high conviction"
        elif ph >= MIN_PROMOTER_HOLD:
            pts = 5;  label = f"Promoter holding {ph:.1f}% — adequate"
        else:
            pts = 0;  label = f"Promoter holding {ph:.1f}% — low"
        score += pts
        detail["promoter_holding"] = f"{label} (+{pts})"
    else:
        detail["promoter_holding"] = "Promoter holding not available (0)"

    return min(score, 100.0), detail


# ─── Sentiment score ─────────────────────────────────────────────────────────

def sentiment_score(symbol: str, fund: dict) -> tuple[float, dict]:
    """
    Proxy sentiment score using available fundamental signals
    that reflect market / analyst mood:
      - Beta (market sensitivity)
      - Profit growth momentum
      - PE vs sector (simple valuation check)

    A full implementation would pipe BSE filings and news through
    an NLP model. This is a robust proxy that works without paid APIs.
    """
    score  = 0.0
    detail = {}

    # Beta — prefer moderate beta for swing trades
    beta = fund.get("beta")
    if beta is not None:
        if 0.8 <= beta <= 1.4:
            pts = 35; label = f"Beta {beta:.2f} — ideal swing range"
        elif beta < 0.8:
            pts = 20; label = f"Beta {beta:.2f} — low volatility"
        elif beta <= 1.8:
            pts = 15; label = f"Beta {beta:.2f} — high, manageable"
        else:
            pts = 0;  label = f"Beta {beta:.2f} — too volatile"
        score += pts
        detail["beta"] = f"{label} (+{pts})"
    else:
        detail["beta"] = "Beta not available (0)"

    # Profit growth
    pg = fund.get("profit_growth")
    if pg is not None:
        if pg >= 20:
            pts = 40; label = f"Profit growth {pg:.1f}% — strong momentum"
        elif pg >= 5:
            pts = 25; label = f"Profit growth {pg:.1f}% — positive"
        elif pg >= 0:
            pts = 10; label = f"Profit growth {pg:.1f}% — flat"
        else:
            pts = 0;  label = f"Profit growth {pg:.1f}% — declining"
        score += pts
        detail["profit_growth"] = f"{label} (+{pts})"
    else:
        detail["profit_growth"] = "Profit growth not available (0)"

    # Valuation sanity — very high PE is a risk for swing trades
    pe = fund.get("pe_ratio")
    if pe is not None and pe > 0:
        if pe <= 20:
            pts = 25; label = f"PE {pe:.1f} — value territory"
        elif pe <= 40:
            pts = 15; label = f"PE {pe:.1f} — fair"
        elif pe <= 70:
            pts = 5;  label = f"PE {pe:.1f} — expensive"
        else:
            pts = 0;  label = f"PE {pe:.1f} — very expensive"
        score += pts
        detail["valuation"] = f"{label} (+{pts})"
    else:
        detail["valuation"] = "PE not available (0)"

    return min(score, 100.0), detail
