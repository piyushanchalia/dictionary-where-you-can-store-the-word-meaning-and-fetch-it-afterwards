"""
config.py — Central configuration for the Swing Trade Alert System
All parameters you may want to tune are here.
"""

# ─── API Keys (fill these in) ───────────────────────────────────────────────
ANTHROPIC_API_KEY   = "YOUR_ANTHROPIC_API_KEY"      # Claude for AI reasoning
TELEGRAM_BOT_TOKEN  = "YOUR_TELEGRAM_BOT_TOKEN"     # Telegram alerts
TELEGRAM_CHAT_ID    = "YOUR_TELEGRAM_CHAT_ID"       # Your chat / group ID
KITE_API_KEY        = ""                             # Zerodha Kite (optional)
KITE_ACCESS_TOKEN   = ""                             # Zerodha Kite (optional)

# ─── Universe ────────────────────────────────────────────────────────────────
# Nifty 50 large caps
NIFTY50_SYMBOLS = [
    "RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK",
    "HINDUNILVR", "ITC", "SBIN", "BHARTIARTL", "BAJFINANCE",
    "KOTAKBANK", "LT", "ASIANPAINT", "AXISBANK", "MARUTI",
    "SUNPHARMA", "TITAN", "ULTRACEMCO", "WIPRO", "NESTLEIND",
    "POWERGRID", "NTPC", "TECHM", "HCLTECH", "ONGC",
    "M&M", "BAJAJFINSV", "TATAMOTORS", "COALINDIA", "ADANIENT",
    "JSWSTEEL", "TATASTEEL", "GRASIM", "DRREDDY", "DIVISLAB",
    "CIPLA", "HINDALCO", "BPCL", "EICHERMOT", "INDUSINDBK",
    "HEROMOTOCO", "APOLLOHOSP", "TATACONSUM", "BRITANNIA",
    "SBILIFE", "HDFCLIFE", "ADANIPORTS", "UPL", "VEDL", "SHREECEM"
]

# Nifty Midcap 50 samples
MIDCAP_SYMBOLS = [
    "ALOKINDS", "ASHOKLEY", "AUROPHARMA", "BALKRISIND", "BEL",
    "BERGEPAINT", "CANBK", "CHOLAFIN", "CONCOR", "COROMANDEL",
    "CROMPTON", "CUMMINSIND", "DALBHARAT", "EMAMILTD", "GMRINFRA",
    "GODREJPROP", "IDFCFIRSTB", "INDUSTOWER", "IRCTC", "JINDALSTEL",
    "JUBLFOOD", "KANSAINER", "LICHSGFIN", "LUPIN", "MFSL",
    "MOTHERSON", "MUTHOOTFIN", "NMDC", "OFSS", "PAGEIND",
    "PEL", "PERSISTENT", "PFC", "PIDILITIND", "PNB",
    "RBLBANK", "RECLTD", "SAIL", "SRF", "TORNTPHARM",
    "TRENT", "TVSMOTOR", "UNIONBANK", "VOLTAS", "ZYDUSLIFE"
]

# Small cap samples
SMALLCAP_SYMBOLS = [
    "MAHSEAMLS", "BALRAMCHIN", "RAIN", "IFCI", "RVNL",
    "RAILVIKAS", "IRFC", "SJVN", "NHPC", "HUDCO"
]

ALL_SYMBOLS = NIFTY50_SYMBOLS + MIDCAP_SYMBOLS + SMALLCAP_SYMBOLS

# ─── Signal weights ───────────────────────────────────────────────────────────
WEIGHT_TECHNICAL    = 0.50
WEIGHT_FUNDAMENTAL  = 0.30
WEIGHT_SENTIMENT    = 0.20

# ─── Technical parameters ────────────────────────────────────────────────────
RSI_PERIOD          = 14
RSI_OVERSOLD        = 40       # Swing buy zone (not extreme oversold)
RSI_OVERBOUGHT      = 70
MACD_FAST           = 12
MACD_SLOW           = 26
MACD_SIGNAL         = 9
EMA_SHORT           = 20
EMA_LONG            = 50
EMA_TREND           = 200
ATR_PERIOD          = 14
VOLUME_SURGE_MULT   = 1.5      # Volume must be 1.5x 20-day avg
LOOKBACK_DAYS       = 90       # Days of price history to fetch

# ─── Fundamental thresholds ──────────────────────────────────────────────────
MAX_DEBT_EQUITY     = 1.5      # D/E ratio ceiling
MIN_ROE             = 10       # Minimum ROE %
MIN_INTEREST_COV    = 2.0      # Interest coverage ratio
MIN_PROMOTER_HOLD   = 30       # Minimum promoter holding %

# ─── Risk & trade parameters ─────────────────────────────────────────────────
MIN_RISK_REWARD     = 2.0      # Minimum R:R ratio
STOPLOSS_ATR_MULT   = 1.5      # Stoploss = entry − (ATR × multiplier)
MAX_STOCKS_PER_DAY  = 7        # Maximum picks delivered each morning
MAX_BETA            = 1.8      # Maximum beta (volatility filter)
MIN_AVG_VOLUME      = 200_000  # Minimum avg daily volume (liquidity)
SWING_DAYS_MIN      = 2
SWING_DAYS_MAX      = 10

# ─── Schedule ────────────────────────────────────────────────────────────────
# System runs data fetch at 8:45 AM, alert fires at 9:10 AM IST
ALERT_TIME          = "09:10"  # HH:MM IST

# ─── Data source ─────────────────────────────────────────────────────────────
# "yfinance" — free, no key needed (suffix .NS added automatically)
# "kite"     — Zerodha Kite Connect (needs API key above)
DATA_SOURCE         = "yfinance"
