"""
main.py — Orchestrator for the Swing Trade Alert System
Ties all 5 layers together and runs them on a daily schedule.

Usage:
  python main.py             # Start the 9:10 AM scheduler (keeps running)
  python main.py --now       # Run immediately (for testing)
  python main.py --symbols RELIANCE TCS INFY  # Run for specific symbols
"""

import argparse
import logging
import sys
from datetime import datetime

import schedule
import time

from config import ALERT_TIME, ALL_SYMBOLS
from data_ingestion  import fetch_all_data
from scorer          import score_all
from ai_reasoning    import enrich_candidates
from alert_delivery  import deliver_alerts

# ─── Logging setup ───────────────────────────────────────────────────────────
logging.basicConfig(
    level   = logging.INFO,
    format  = "%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    handlers = [
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/swing_trader.log", mode="a")
    ]
)
logger = logging.getLogger("main")


# ─── Pipeline ────────────────────────────────────────────────────────────────

def run_pipeline(symbols: list[str] = None):
    """
    Full pipeline:
      Layer 1 → Fetch data
      Layer 2 → Compute signals
      Layer 3 → Score, filter, rank
      Layer 4 → AI reasoning
      Layer 5 → Deliver alerts
    """
    start_time = datetime.now()
    symbols    = symbols or ALL_SYMBOLS

    logger.info("=" * 60)
    logger.info(f"Pipeline started — {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"Universe: {len(symbols)} symbols")
    logger.info("=" * 60)

    # Layer 1: Data ingestion
    logger.info("[ Layer 1 ] Fetching price + fundamental data …")
    data = fetch_all_data(symbols)

    if not data:
        logger.error("No data fetched — aborting pipeline")
        return

    # Layer 2 + 3: Signal computation + scoring
    logger.info("[ Layer 2/3 ] Computing signals and ranking …")
    shortlist = score_all(data)

    if not shortlist:
        logger.warning("No stocks passed filters today")
        deliver_alerts([])
        return

    logger.info(f"  → {len(shortlist)} stocks shortlisted")
    for s in shortlist:
        logger.info(f"     {s.symbol:15s} composite={s.composite_score:.1f} "
                    f"entry=₹{s.entry_price} sl=₹{s.stoploss} tgt=₹{s.target_price}")

    # Layer 4: AI reasoning
    logger.info("[ Layer 4 ] Generating AI rationale …")
    trade_cards = enrich_candidates(shortlist)

    # Layer 5: Delivery
    logger.info("[ Layer 5 ] Delivering alerts …")
    deliver_alerts(trade_cards)

    elapsed = (datetime.now() - start_time).seconds
    logger.info(f"Pipeline complete in {elapsed}s")


# ─── Scheduler ───────────────────────────────────────────────────────────────

def start_scheduler():
    """Schedule the pipeline to run every weekday at ALERT_TIME (IST)."""
    logger.info(f"Scheduler started — will run pipeline daily at {ALERT_TIME} IST")
    logger.info("Press Ctrl+C to stop.")

    schedule.every().monday.at(ALERT_TIME).do(run_pipeline)
    schedule.every().tuesday.at(ALERT_TIME).do(run_pipeline)
    schedule.every().wednesday.at(ALERT_TIME).do(run_pipeline)
    schedule.every().thursday.at(ALERT_TIME).do(run_pipeline)
    schedule.every().friday.at(ALERT_TIME).do(run_pipeline)

    while True:
        schedule.run_pending()
        time.sleep(30)


# ─── CLI ─────────────────────────────────────────────────────────────────────

def main():
    import os
    os.makedirs("logs", exist_ok=True)

    parser = argparse.ArgumentParser(description="Swing Trade Alert System")
    parser.add_argument("--now",     action="store_true",
                        help="Run pipeline immediately")
    parser.add_argument("--symbols", nargs="+", metavar="SYM",
                        help="Run for specific symbols only (e.g. RELIANCE TCS)")
    args = parser.parse_args()

    if args.now or args.symbols:
        syms = args.symbols or ALL_SYMBOLS
        run_pipeline(syms)
    else:
        start_scheduler()


if __name__ == "__main__":
    main()
