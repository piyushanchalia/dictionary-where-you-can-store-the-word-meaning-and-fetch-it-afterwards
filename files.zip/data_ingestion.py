"""
data_ingestion.py — Layer 1: Fetch price, volume, and fundamental data
Supports yfinance (free) and Zerodha Kite Connect.
"""

import logging
from datetime import datetime, timedelta
from typing import Optional

import pandas as pd
import yfinance as yf

from config import (
    ALL_SYMBOLS, DATA_SOURCE, LOOKBACK_DAYS,
    KITE_API_KEY, KITE_ACCESS_TOKEN
)

logger = logging.getLogger(__name__)


# ─── Price / OHLCV ───────────────────────────────────────────────────────────

def fetch_price_data(symbol: str, days: int = LOOKBACK_DAYS) -> Optional[pd.DataFrame]:
    """
    Returns a DataFrame with columns: Open, High, Low, Close, Volume
    indexed by date. Returns None if fetch fails.
    """
    try:
        if DATA_SOURCE == "yfinance":
            return _fetch_yfinance(symbol, days)
        elif DATA_SOURCE == "kite":
            return _fetch_kite(symbol, days)
        else:
            raise ValueError(f"Unknown DATA_SOURCE: {DATA_SOURCE}")
    except Exception as e:
        logger.warning(f"Failed to fetch price data for {symbol}: {e}")
        return None


def _fetch_yfinance(symbol: str, days: int) -> Optional[pd.DataFrame]:
    """yfinance uses NSE suffix .NS for Indian stocks."""
    ticker = f"{symbol}.NS"
    end   = datetime.today()
    start = end - timedelta(days=days + 10)   # buffer for weekends/holidays

    df = yf.download(ticker, start=start, end=end, progress=False, auto_adjust=True)
    if df.empty:
        return None

    df = df[["Open", "High", "Low", "Close", "Volume"]].copy()
    df.index = pd.to_datetime(df.index)
    df = df.dropna().tail(days)
    return df


def _fetch_kite(symbol: str, days: int) -> Optional[pd.DataFrame]:
    """Zerodha Kite Connect — requires KiteConnect installed and auth."""
    try:
        from kiteconnect import KiteConnect
        kite = KiteConnect(api_key=KITE_API_KEY)
        kite.set_access_token(KITE_ACCESS_TOKEN)

        end   = datetime.today()
        start = end - timedelta(days=days + 10)

        records = kite.historical_data(
            instrument_token=_kite_instrument_token(kite, symbol),
            from_date=start, to_date=end, interval="day"
        )
        df = pd.DataFrame(records).set_index("date")
        df.index = pd.to_datetime(df.index)
        df = df.rename(columns={"open": "Open", "high": "High",
                                 "low": "Low", "close": "Close", "volume": "Volume"})
        return df[["Open", "High", "Low", "Close", "Volume"]].tail(days)
    except Exception as e:
        logger.warning(f"Kite fetch failed for {symbol}: {e}")
        return None


def _kite_instrument_token(kite, symbol: str) -> int:
    """Look up instrument token for NSE symbol."""
    instruments = kite.instruments("NSE")
    for inst in instruments:
        if inst["tradingsymbol"] == symbol:
            return inst["instrument_token"]
    raise ValueError(f"Instrument token not found for {symbol}")


# ─── Fundamentals ────────────────────────────────────────────────────────────

def fetch_fundamentals(symbol: str) -> dict:
    """
    Returns key fundamental metrics from yfinance.
    Falls back to empty dict on failure.
    """
    defaults = {
        "debt_to_equity": None,
        "roe": None,
        "interest_coverage": None,
        "promoter_holding": None,
        "revenue_growth": None,
        "profit_growth": None,
        "pe_ratio": None,
        "market_cap": None,
        "beta": None,
        "sector": None,
        "company_name": symbol,
    }
    try:
        ticker = yf.Ticker(f"{symbol}.NS")
        info   = ticker.info

        defaults.update({
            "debt_to_equity":    info.get("debtToEquity"),
            "roe":               _pct(info.get("returnOnEquity")),
            "interest_coverage": info.get("ebitda") and info.get("interestExpense") and
                                 abs(info["ebitda"] / info["interestExpense"])
                                 if info.get("interestExpense") else None,
            "revenue_growth":    _pct(info.get("revenueGrowth")),
            "profit_growth":     _pct(info.get("earningsGrowth")),
            "pe_ratio":          info.get("trailingPE"),
            "market_cap":        info.get("marketCap"),
            "beta":              info.get("beta"),
            "sector":            info.get("sector"),
            "company_name":      info.get("longName", symbol),
        })

        # Promoter holding — available in some tickers
        major = ticker.major_holders
        if major is not None and not major.empty:
            try:
                # Row 0 typically: "% of Shares Held by All Insider"
                val = major.iloc[0, 0]
                defaults["promoter_holding"] = float(str(val).replace("%", ""))
            except Exception:
                pass

    except Exception as e:
        logger.warning(f"Fundamentals fetch failed for {symbol}: {e}")

    return defaults


def _pct(val) -> Optional[float]:
    """Convert decimal ratio to percentage."""
    if val is None:
        return None
    return round(float(val) * 100, 2)


# ─── Batch fetch ─────────────────────────────────────────────────────────────

def fetch_all_data(symbols: list[str]) -> dict:
    """
    Returns {symbol: {"price": df, "fundamentals": dict}}
    for all symbols. Skips symbols where price fetch fails.
    """
    logger.info(f"Fetching data for {len(symbols)} symbols …")
    result = {}
    for sym in symbols:
        df = fetch_price_data(sym)
        if df is None or len(df) < 30:
            logger.debug(f"Skipping {sym} — insufficient price data")
            continue
        fundamentals = fetch_fundamentals(sym)
        result[sym] = {"price": df, "fundamentals": fundamentals}
        logger.debug(f"  {sym}: {len(df)} rows, cap={fundamentals.get('market_cap')}")

    logger.info(f"Data ready for {len(result)} symbols")
    return result
