"""
scorer.py — Layer 3: Composite scoring, hard filters, and final ranking
Takes raw signal scores and produces a ranked shortlist.
"""

import logging
from dataclasses import dataclass, field

from config import (
    WEIGHT_TECHNICAL, WEIGHT_FUNDAMENTAL, WEIGHT_SENTIMENT,
    MAX_DEBT_EQUITY, MAX_BETA, MIN_AVG_VOLUME,
    MIN_RISK_REWARD, STOPLOSS_ATR_MULT, MAX_STOCKS_PER_DAY
)
from signals_technical   import technical_score
from signals_fundamental import fundamental_score, sentiment_score

logger = logging.getLogger(__name__)


@dataclass
class StockCandidate:
    symbol:            str
    company_name:      str
    sector:            str
    cap_type:          str              # "Large", "Mid", "Small"

    tech_score:        float = 0.0
    fund_score:        float = 0.0
    sent_score:        float = 0.0
    composite_score:   float = 0.0

    tech_detail:       dict  = field(default_factory=dict)
    fund_detail:       dict  = field(default_factory=dict)
    sent_detail:       dict  = field(default_factory=dict)
    fundamentals:      dict  = field(default_factory=dict)

    # Trade levels (populated by compute_trade_levels)
    entry_price:       float = 0.0
    stoploss:          float = 0.0
    target_price:      float = 0.0
    expected_return:   float = 0.0     # %
    risk_reward:       float = 0.0
    atr:               float = 0.0
    last_close:        float = 0.0
    holding_days:      str   = "3–7 days"


# ─── Hard filters ─────────────────────────────────────────────────────────────

def passes_hard_filters(symbol: str, fund: dict, tech_detail: dict) -> tuple[bool, str]:
    """
    Returns (True, "") if the stock passes all hard filters,
    or (False, reason) if it should be excluded.
    """
    de   = fund.get("debt_to_equity")
    beta = fund.get("beta")

    if de is not None and de > MAX_DEBT_EQUITY:
        return False, f"D/E {de:.1f} > {MAX_DEBT_EQUITY} limit"

    if beta is not None and beta > MAX_BETA:
        return False, f"Beta {beta:.1f} > {MAX_BETA} limit"

    avg_vol = _estimate_avg_volume(tech_detail)
    if avg_vol is not None and avg_vol < MIN_AVG_VOLUME:
        return False, f"Avg volume {avg_vol:,} < {MIN_AVG_VOLUME:,} — illiquid"

    return True, ""


def _estimate_avg_volume(tech_detail: dict) -> float | None:
    """Not directly stored — caller can pass None to skip this check."""
    return None   # Extend if you persist avg volume in tech_detail


# ─── Trade level computation ──────────────────────────────────────────────────

def compute_trade_levels(candidate: StockCandidate) -> StockCandidate:
    """
    Sets entry, stoploss, target, expected return, and R:R on the candidate.

    Entry   = last close (buy at open confirmation near CMP)
    Stoploss = entry − (ATR × multiplier)  or last swing low proxy
    Target  = nearest resistance proxy: entry + 2× risk  (min R:R = 2)
    """
    close = candidate.last_close
    atr   = candidate.atr

    if close <= 0 or atr <= 0:
        return candidate

    entry    = round(close, 2)
    sl_dist  = round(atr * STOPLOSS_ATR_MULT, 2)
    stoploss = round(entry - sl_dist, 2)
    target   = round(entry + sl_dist * MIN_RISK_REWARD, 2)   # R:R = 2

    candidate.entry_price     = entry
    candidate.stoploss        = stoploss
    candidate.target_price    = target
    candidate.risk_reward     = MIN_RISK_REWARD
    candidate.expected_return = round((target - entry) / entry * 100, 2)
    candidate.atr             = round(atr, 2)

    # Estimated holding: higher score = faster move
    cs = candidate.composite_score
    if cs >= 75:
        candidate.holding_days = "2–4 days"
    elif cs >= 55:
        candidate.holding_days = "4–7 days"
    else:
        candidate.holding_days = "7–10 days"

    return candidate


# ─── Cap classification ───────────────────────────────────────────────────────

from config import NIFTY50_SYMBOLS, MIDCAP_SYMBOLS

def classify_cap(symbol: str) -> str:
    if symbol in NIFTY50_SYMBOLS:
        return "Large"
    if symbol in MIDCAP_SYMBOLS:
        return "Mid"
    return "Small"


# ─── Main scorer ─────────────────────────────────────────────────────────────

def score_all(data: dict) -> list[StockCandidate]:
    """
    data: {symbol: {"price": df, "fundamentals": dict}}
    Returns a list of StockCandidate objects, sorted by composite score desc.
    """
    candidates = []

    for symbol, payload in data.items():
        df   = payload["price"]
        fund = payload["fundamentals"]

        # Compute individual scores
        t_score, t_detail = technical_score(df)
        f_score, f_detail = fundamental_score(fund)
        s_score, s_detail = sentiment_score(symbol, fund)

        # Hard filters
        passed, reason = passes_hard_filters(symbol, fund, t_detail)
        if not passed:
            logger.debug(f"  {symbol} filtered out: {reason}")
            continue

        # Composite
        composite = (
            t_score * WEIGHT_TECHNICAL +
            f_score * WEIGHT_FUNDAMENTAL +
            s_score * WEIGHT_SENTIMENT
        )

        c = StockCandidate(
            symbol        = symbol,
            company_name  = fund.get("company_name", symbol),
            sector        = fund.get("sector") or "Unknown",
            cap_type      = classify_cap(symbol),
            tech_score    = round(t_score, 1),
            fund_score    = round(f_score, 1),
            sent_score    = round(s_score, 1),
            composite_score = round(composite, 1),
            tech_detail   = t_detail,
            fund_detail   = f_detail,
            sent_detail   = s_detail,
            fundamentals  = fund,
            last_close    = t_detail.get("last_close", 0.0),
            atr           = t_detail.get("atr", 0.0),
        )
        c = compute_trade_levels(c)
        candidates.append(c)

    # Sort descending by composite score
    candidates.sort(key=lambda x: x.composite_score, reverse=True)

    # Ensure sector diversity: avoid 3+ stocks from same sector in top picks
    selected = _diversify(candidates, MAX_STOCKS_PER_DAY)
    logger.info(f"Scored {len(candidates)} stocks → {len(selected)} selected after diversity filter")
    return selected


def _diversify(ranked: list[StockCandidate], n: int) -> list[StockCandidate]:
    """Pick top n stocks while limiting 2 per sector."""
    sector_count: dict[str, int] = {}
    selected = []
    for c in ranked:
        count = sector_count.get(c.sector, 0)
        if count < 2:
            selected.append(c)
            sector_count[c.sector] = count + 1
        if len(selected) >= n:
            break
    return selected
