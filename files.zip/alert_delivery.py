"""
alert_delivery.py — Layer 5: Format and send trade cards
Supports Telegram Bot, console print, and a JSON log file.
"""

import json
import logging
from datetime import date, datetime
from pathlib import Path

from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID

logger = logging.getLogger(__name__)

LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)


# ─── Formatters ──────────────────────────────────────────────────────────────

def format_telegram_message(card: dict, index: int, total: int) -> str:
    """Returns a Telegram-formatted message string (MarkdownV2 compatible)."""

    conf_emoji = {"High": "🟢", "Medium": "🟡", "Low": "🔴"}.get(card.get("confidence", ""), "⚪")
    cap_label  = {"Large": "🏛 Large cap", "Mid": "🏢 Mid cap", "Small": "🏗 Small cap"}.get(
                  card.get("cap_type", ""), card.get("cap_type", ""))

    msg = (
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 *Pick {index}/{total}* — {card['company_name']} `{card['symbol']}`\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"🏷 {cap_label}  |  {card.get('sector', 'Unknown')}\n\n"
        f"💰 *Entry:*   ₹{card['entry_price']}\n"
        f"🛑 *Stoploss:* ₹{card['stoploss']}\n"
        f"🎯 *Target:*  ₹{card['target_price']}\n"
        f"📈 *Return:*  {card['expected_return']}% in {card['holding_days']}\n"
        f"⚖️ *R\\:R:*   {card['risk_reward']}\n\n"
        f"📝 *Why buy?*\n{card.get('why_buy', 'N/A')}\n\n"
        f"✅ *Key strength:* {card.get('key_strength', 'N/A')}\n"
        f"⚠️ *Key risk:*    {card.get('key_risk', 'N/A')}\n"
        f"🔮 *Catalyst:*    {card.get('catalyst', 'N/A')}\n"
        f"🚪 *Exit plan:*   {card.get('exit_strategy', 'N/A')}\n\n"
        f"📊 Scores → Tech: {card['tech_score']} | Fund: {card['fund_score']} "
        f"| Sent: {card['sent_score']} | Total: {card['composite_score']}/100\n"
        f"{conf_emoji} Confidence: *{card.get('confidence', 'N/A')}*"
    )
    return msg


def format_console_card(card: dict, index: int, total: int) -> str:
    """Returns a clean plain-text card for terminal output."""
    line = "─" * 55
    return (
        f"\n{line}\n"
        f" PICK {index}/{total}: {card['company_name']} ({card['symbol']}) "
        f"| {card.get('cap_type')} Cap | {card.get('sector')}\n"
        f"{line}\n"
        f" Entry     : ₹{card['entry_price']}\n"
        f" Stoploss  : ₹{card['stoploss']}\n"
        f" Target    : ₹{card['target_price']}\n"
        f" Return    : {card['expected_return']}% in {card['holding_days']}\n"
        f" R:R       : {card['risk_reward']}\n"
        f" Confidence: {card.get('confidence')}\n"
        f"\n WHY BUY?\n {card.get('why_buy')}\n"
        f"\n KEY STRENGTH : {card.get('key_strength')}\n"
        f" KEY RISK     : {card.get('key_risk')}\n"
        f" CATALYST     : {card.get('catalyst')}\n"
        f" EXIT PLAN    : {card.get('exit_strategy')}\n"
        f"\n SCORES → Tech:{card['tech_score']} | Fund:{card['fund_score']} "
        f"| Sent:{card['sent_score']} | Composite:{card['composite_score']}/100\n"
        f"{line}"
    )


def format_header(total: int) -> str:
    today = date.today().strftime("%A, %d %B %Y")
    return (
        f"🌅 *SWING TRADE PICKS — {today}*\n"
        f"📌 {total} stocks selected for 2–10 day holds\n"
        f"⚡ Market opens in ~15 minutes — confirm entries at open\n"
        f"━━━━━━━━━━━━━━━━━━━━━"
    )


# ─── Delivery channels ───────────────────────────────────────────────────────

def send_telegram(text: str):
    """Send a message via Telegram Bot API."""
    if not TELEGRAM_BOT_TOKEN or TELEGRAM_BOT_TOKEN == "YOUR_TELEGRAM_BOT_TOKEN":
        logger.info("Telegram not configured — skipping")
        return
    try:
        import requests
        url  = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        data = {
            "chat_id":    TELEGRAM_CHAT_ID,
            "text":       text,
            "parse_mode": "Markdown",
        }
        r = requests.post(url, data=data, timeout=10)
        if r.status_code == 200:
            logger.info("Telegram message sent successfully")
        else:
            logger.warning(f"Telegram error {r.status_code}: {r.text[:200]}")
    except Exception as e:
        logger.error(f"Telegram send failed: {e}")


def log_to_json(trade_cards: list[dict]):
    """Append today's picks to a daily JSON log for performance tracking."""
    today    = date.today().isoformat()
    log_path = LOG_DIR / f"picks_{today}.json"
    payload  = {
        "date":        today,
        "generated_at": datetime.now().isoformat(),
        "picks":       trade_cards
    }
    with open(log_path, "w") as f:
        json.dump(payload, f, indent=2, default=str)
    logger.info(f"Trade cards saved → {log_path}")


# ─── Main delivery function ───────────────────────────────────────────────────

def deliver_alerts(trade_cards: list[dict]):
    """
    Delivers all trade cards via:
      1. Console (always)
      2. Telegram (if configured)
      3. JSON log file
    """
    total = len(trade_cards)
    if total == 0:
        logger.warning("No trade cards to deliver today.")
        print("\n⚠️  No stocks passed all filters today. Market may be weak.\n")
        return

    # Console header
    print(f"\n{'═'*55}")
    print(f"  SWING TRADE PICKS — {date.today().strftime('%d %b %Y')}  ({total} picks)")
    print(f"{'═'*55}")

    # Telegram header
    send_telegram(format_header(total))

    for i, card in enumerate(trade_cards, 1):
        # Console
        print(format_console_card(card, i, total))

        # Telegram
        send_telegram(format_telegram_message(card, i, total))

    # JSON log
    log_to_json(trade_cards)
    logger.info(f"Alert delivery complete — {total} picks sent")
