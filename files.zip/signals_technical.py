"""
signals_technical.py — Layer 2a: Technical signal computation
Computes RSI, MACD, EMAs, breakout, volume surge, ATR, and a composite
technical score (0–100) for each symbol.
"""

import numpy as np
import pandas as pd

from config import (
    RSI_PERIOD, RSI_OVERSOLD, RSI_OVERBOUGHT,
    MACD_FAST, MACD_SLOW, MACD_SIGNAL,
    EMA_SHORT, EMA_LONG, EMA_TREND,
    ATR_PERIOD, VOLUME_SURGE_MULT
)


# ─── Individual indicators ───────────────────────────────────────────────────

def compute_rsi(close: pd.Series, period: int = RSI_PERIOD) -> pd.Series:
    delta = close.diff()
    gain  = delta.clip(lower=0)
    loss  = (-delta).clip(lower=0)
    avg_gain = gain.ewm(com=period - 1, min_periods=period).mean()
    avg_loss = loss.ewm(com=period - 1, min_periods=period).mean()
    rs  = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    return rsi


def compute_macd(close: pd.Series) -> tuple[pd.Series, pd.Series, pd.Series]:
    """Returns (macd_line, signal_line, histogram)."""
    ema_fast   = close.ewm(span=MACD_FAST,   adjust=False).mean()
    ema_slow   = close.ewm(span=MACD_SLOW,   adjust=False).mean()
    macd_line  = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=MACD_SIGNAL, adjust=False).mean()
    histogram  = macd_line - signal_line
    return macd_line, signal_line, histogram


def compute_emas(close: pd.Series) -> tuple[pd.Series, pd.Series, pd.Series]:
    """Returns (ema20, ema50, ema200)."""
    return (
        close.ewm(span=EMA_SHORT, adjust=False).mean(),
        close.ewm(span=EMA_LONG,  adjust=False).mean(),
        close.ewm(span=EMA_TREND, adjust=False).mean(),
    )


def compute_atr(df: pd.DataFrame, period: int = ATR_PERIOD) -> pd.Series:
    high, low, close = df["High"], df["Low"], df["Close"]
    prev_close = close.shift(1)
    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low  - prev_close).abs()
    ], axis=1).max(axis=1)
    return tr.ewm(span=period, adjust=False).mean()


def compute_volume_ratio(volume: pd.Series, window: int = 20) -> float:
    """Today's volume divided by 20-day average."""
    if len(volume) < window + 1:
        return 1.0
    avg = volume.iloc[-(window + 1):-1].mean()
    return float(volume.iloc[-1] / avg) if avg > 0 else 1.0


def detect_breakout(df: pd.DataFrame, lookback: int = 20) -> bool:
    """
    True when today's close breaks above the highest high
    of the previous `lookback` candles.
    """
    if len(df) < lookback + 1:
        return False
    prev_high = df["High"].iloc[-(lookback + 1):-1].max()
    return float(df["Close"].iloc[-1]) > float(prev_high)


def detect_support_bounce(df: pd.DataFrame, lookback: int = 20) -> bool:
    """
    True when price is near a recent support zone
    (within 2% of the lowest low in the window).
    """
    if len(df) < lookback + 1:
        return False
    prev_low   = df["Low"].iloc[-(lookback + 1):-1].min()
    curr_close = float(df["Close"].iloc[-1])
    return curr_close <= prev_low * 1.02


# ─── Composite technical score ───────────────────────────────────────────────

def technical_score(df: pd.DataFrame) -> tuple[float, dict]:
    """
    Returns (score 0–100, detail_dict with individual signals).
    Higher score = stronger technical setup.
    """
    close  = df["Close"]
    volume = df["Volume"]

    rsi                         = compute_rsi(close)
    macd_line, signal, hist     = compute_macd(close)
    ema20, ema50, ema200        = compute_emas(close)
    atr                         = compute_atr(df)

    last_rsi    = float(rsi.iloc[-1])
    last_macd   = float(macd_line.iloc[-1])
    last_signal = float(signal.iloc[-1])
    last_hist   = float(hist.iloc[-1])
    prev_hist   = float(hist.iloc[-2]) if len(hist) > 1 else 0.0
    last_close  = float(close.iloc[-1])
    last_ema20  = float(ema20.iloc[-1])
    last_ema50  = float(ema50.iloc[-1])
    last_ema200 = float(ema200.iloc[-1])
    last_atr    = float(atr.iloc[-1])
    vol_ratio   = compute_volume_ratio(volume)
    breakout    = detect_breakout(df)
    support_bnc = detect_support_bounce(df)

    score = 0.0
    detail = {}

    # RSI in swing-buy zone (40–60 with upward momentum)
    if RSI_OVERSOLD <= last_rsi <= 60:
        pts = 20
        score += pts
        detail["rsi"] = f"{last_rsi:.1f} — in swing buy zone (+{pts})"
    elif last_rsi < RSI_OVERSOLD:
        pts = 12
        score += pts
        detail["rsi"] = f"{last_rsi:.1f} — oversold, watch for reversal (+{pts})"
    else:
        detail["rsi"] = f"{last_rsi:.1f} — overbought (0)"

    # MACD bullish crossover or positive histogram turning up
    if last_macd > last_signal and last_hist > prev_hist:
        pts = 20
        score += pts
        detail["macd"] = f"Bullish crossover, histogram rising (+{pts})"
    elif last_hist > prev_hist:
        pts = 10
        score += pts
        detail["macd"] = f"Histogram turning up (+{pts})"
    else:
        detail["macd"] = "No bullish MACD signal (0)"

    # Price above key EMAs
    ema_pts = 0
    ema_notes = []
    if last_close > last_ema20:
        ema_pts += 7; ema_notes.append("above EMA20")
    if last_close > last_ema50:
        ema_pts += 8; ema_notes.append("above EMA50")
    if last_close > last_ema200:
        ema_pts += 10; ema_notes.append("above EMA200")
    score += ema_pts
    detail["ema"] = f"{', '.join(ema_notes) or 'below all EMAs'} (+{ema_pts})"

    # Breakout
    if breakout:
        pts = 20
        score += pts
        detail["breakout"] = f"Breaking 20-day high (+{pts})"
    elif support_bnc:
        pts = 10
        score += pts
        detail["breakout"] = f"Bouncing off support zone (+{pts})"
    else:
        detail["breakout"] = "No breakout / support bounce (0)"

    # Volume surge
    if vol_ratio >= VOLUME_SURGE_MULT:
        pts = 15
        score += pts
        detail["volume"] = f"{vol_ratio:.1f}x avg volume — surge (+{pts})"
    elif vol_ratio >= 1.2:
        pts = 7
        score += pts
        detail["volume"] = f"{vol_ratio:.1f}x avg volume — above avg (+{pts})"
    else:
        detail["volume"] = f"{vol_ratio:.1f}x avg volume — low (0)"

    # ATR and trade levels (stored for use in trade card)
    detail["atr"]         = round(last_atr, 2)
    detail["last_close"]  = round(last_close, 2)
    detail["ema20"]       = round(last_ema20, 2)
    detail["ema50"]       = round(last_ema50, 2)
    detail["ema200"]      = round(last_ema200, 2)

    return min(score, 100.0), detail
