"""
ai_reasoning.py — Layer 4: AI-generated rationale for each trade pick
Calls Claude (claude-sonnet-4-20250514) via the Anthropic API to produce
a structured, plain-English trade rationale for each shortlisted stock.
"""

import json
import logging
from anthropic import Anthropic

from config import ANTHROPIC_API_KEY
from scorer import StockCandidate

logger = logging.getLogger(__name__)
client = Anthropic(api_key=ANTHROPIC_API_KEY)

SYSTEM_PROMPT = """You are a professional Indian equity swing trade analyst.
Given a stock's technical and fundamental data, you produce a concise, 
structured trade rationale in JSON. Be specific, cite the actual numbers 
provided. Avoid generic statements. Output ONLY valid JSON — no extra text."""

TRADE_CARD_SCHEMA = """{
  "why_buy":        "2–3 sentence reason citing specific signals",
  "key_strength":   "single strongest bullish factor",
  "key_risk":       "single biggest risk to this trade",
  "confidence":     "High / Medium / Low",
  "catalyst":       "what could trigger the move (earnings, sector, technical)",
  "exit_strategy":  "when / why to exit beyond stoploss"
}"""


def generate_rationale(c: StockCandidate) -> dict:
    """
    Calls Claude to generate a trade rationale for a StockCandidate.
    Returns a dict with keys from TRADE_CARD_SCHEMA.
    Falls back to a rule-based rationale on API failure.
    """
    prompt = _build_prompt(c)
    try:
        response = client.messages.create(
            model      = "claude-sonnet-4-20250514",
            max_tokens = 600,
            system     = SYSTEM_PROMPT,
            messages   = [{"role": "user", "content": prompt}]
        )
        raw = response.content[0].text.strip()
        # Strip markdown fences if present
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        return json.loads(raw)
    except Exception as e:
        logger.warning(f"AI reasoning failed for {c.symbol}: {e}")
        return _fallback_rationale(c)


def _build_prompt(c: StockCandidate) -> str:
    f = c.fundamentals
    td = c.tech_detail

    return f"""
Stock: {c.company_name} ({c.symbol}) — {c.cap_type} Cap | Sector: {c.sector}

=== Trade Levels ===
Entry:           ₹{c.entry_price}
Stoploss:        ₹{c.stoploss}  (ATR-based, {c.atr} ATR)
Target:          ₹{c.target_price}
Expected return: {c.expected_return}%
Risk:Reward:     1:{c.risk_reward}
Holding period:  {c.holding_days}

=== Technical Signals (score {c.tech_score}/100) ===
{_format_dict(td, exclude=["atr","last_close","ema20","ema50","ema200"])}
EMA levels: EMA20={td.get("ema20")}, EMA50={td.get("ema50")}, EMA200={td.get("ema200")}
ATR: {c.atr}

=== Fundamental Signals (score {c.fund_score}/100) ===
D/E ratio:        {f.get("debt_to_equity", "N/A")}
ROE:              {f.get("roe", "N/A")}%
Interest coverage:{f.get("interest_coverage", "N/A")}x
Revenue growth:   {f.get("revenue_growth", "N/A")}%
Profit growth:    {f.get("profit_growth", "N/A")}%
Promoter holding: {f.get("promoter_holding", "N/A")}%
PE ratio:         {f.get("pe_ratio", "N/A")}

=== Sentiment Signals (score {c.sent_score}/100) ===
{_format_dict(c.sent_detail)}

=== Composite Score: {c.composite_score}/100 ===

Produce a trade rationale strictly following this JSON schema:
{TRADE_CARD_SCHEMA}
""".strip()


def _format_dict(d: dict, exclude: list = None) -> str:
    exclude = exclude or []
    lines = []
    for k, v in d.items():
        if k not in exclude:
            lines.append(f"  {k}: {v}")
    return "\n".join(lines) if lines else "  (no data)"


def _fallback_rationale(c: StockCandidate) -> dict:
    """Rule-based fallback when Claude API is unavailable."""
    td = c.tech_detail
    reasons = []

    if "Bullish crossover" in td.get("macd", ""):
        reasons.append("MACD showing bullish crossover")
    if "in swing buy zone" in td.get("rsi", ""):
        reasons.append(f"RSI in optimal swing buy zone")
    if "Breaking" in td.get("breakout", ""):
        reasons.append("breaking out above 20-day resistance")
    if "surge" in td.get("volume", ""):
        reasons.append("strong volume confirmation")

    why = f"{c.company_name} shows technical strength: " + ", ".join(reasons) + "." if reasons \
          else f"{c.company_name} scores {c.composite_score}/100 on composite signals."

    return {
        "why_buy":       why,
        "key_strength":  td.get("macd", "Technical momentum"),
        "key_risk":      "General market weakness could override stock-specific signals.",
        "confidence":    "High" if c.composite_score >= 70 else "Medium" if c.composite_score >= 50 else "Low",
        "catalyst":      "Technical breakout with volume confirmation",
        "exit_strategy": f"Exit at target ₹{c.target_price} or stoploss ₹{c.stoploss}. "
                         f"Trail stoploss after 3% gain."
    }


def enrich_candidates(candidates: list[StockCandidate]) -> list[dict]:
    """
    Takes shortlisted StockCandidates, enriches each with AI rationale,
    and returns a list of complete trade-card dicts ready for delivery.
    """
    trade_cards = []
    for c in candidates:
        logger.info(f"Generating rationale for {c.symbol} …")
        rationale = generate_rationale(c)
        card = {
            "symbol":          c.symbol,
            "company_name":    c.company_name,
            "sector":          c.sector,
            "cap_type":        c.cap_type,
            "entry_price":     c.entry_price,
            "stoploss":        c.stoploss,
            "target_price":    c.target_price,
            "expected_return": c.expected_return,
            "risk_reward":     f"1:{c.risk_reward}",
            "holding_days":    c.holding_days,
            "composite_score": c.composite_score,
            "tech_score":      c.tech_score,
            "fund_score":      c.fund_score,
            "sent_score":      c.sent_score,
            **rationale
        }
        trade_cards.append(card)
    return trade_cards
