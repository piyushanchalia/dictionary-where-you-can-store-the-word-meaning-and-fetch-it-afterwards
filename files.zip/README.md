# Swing Trade Alert System

Automated pipeline that delivers 5–7 swing trade picks every morning at 9:10 AM
with entry price, stoploss, target, expected return, holding period, and AI-generated
reasoning — before the NSE/BSE market opens.

---

## Architecture

```
Layer 1 — Data ingestion      fetch_all_data()       data_ingestion.py
Layer 2 — Signal engine       technical_score()      signals_technical.py
                              fundamental_score()    signals_fundamental.py
                              sentiment_score()
Layer 3 — Scoring & filter    score_all()            scorer.py
Layer 4 — AI reasoning        enrich_candidates()    ai_reasoning.py
Layer 5 — Delivery            deliver_alerts()       alert_delivery.py
                              start_scheduler()      main.py
```

---

## Quick start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Fill in your API keys in config.py
```python
ANTHROPIC_API_KEY  = "sk-ant-..."   # Required for AI rationale
TELEGRAM_BOT_TOKEN = "..."          # Optional — for Telegram alerts
TELEGRAM_CHAT_ID   = "..."          # Your Telegram chat / group ID
```

How to get a Telegram bot token:
1. Message @BotFather on Telegram
2. Send /newbot and follow prompts
3. Copy the token into config.py
4. Get your chat ID by messaging @userinfobot

### 3. Test immediately (don't wait for 9:10 AM)
```bash
python main.py --now
```

Test with specific symbols:
```bash
python main.py --symbols RELIANCE TCS HDFCBANK INFY TATAMOTORS
```

### 4. Start the daily scheduler
```bash
python main.py
```
Runs Monday–Friday at 9:10 AM. Keep the process alive (use screen / tmux / systemd).

---

## Sample output (console)

```
═══════════════════════════════════════════════════════
  SWING TRADE PICKS — 20 May 2026  (5 picks)
═══════════════════════════════════════════════════════

───────────────────────────────────────────────────────
 PICK 1/5: Reliance Industries (RELIANCE) | Large Cap | Energy
───────────────────────────────────────────────────────
 Entry     : ₹2,945.00
 Stoploss  : ₹2,880.50
 Target    : ₹3,074.00
 Return    : 4.4% in 4–7 days
 R:R       : 1:2.0
 Confidence: High

 WHY BUY?
 MACD shows bullish crossover with rising histogram. RSI at 52
 in the optimal swing buy zone. Breaking 20-day resistance with
 1.7x volume surge — institutional accumulation likely.

 KEY STRENGTH : MACD bullish crossover, histogram rising
 KEY RISK     : Global crude oil price weakness could drag sector
 CATALYST     : Technical breakout with volume confirmation
 EXIT PLAN    : Exit at ₹3,074 or trail SL after 3% gain.

 SCORES → Tech:78.0 | Fund:65.0 | Sent:72.0 | Composite:73.0/100
───────────────────────────────────────────────────────
```

---

## Sample Telegram alert

```
🌅 SWING TRADE PICKS — Tuesday, 20 May 2026
📌 5 stocks selected for 2–10 day holds
⚡ Market opens in ~15 minutes — confirm entries at open

━━━━━━━━━━━━━━━━━━━━━
📊 Pick 1/5 — Reliance Industries RELIANCE
━━━━━━━━━━━━━━━━━━━━━
🏛 Large cap  |  Energy

💰 Entry:    ₹2,945.00
🛑 Stoploss: ₹2,880.50
🎯 Target:   ₹3,074.00
📈 Return:   4.4% in 4–7 days
⚖️ R:R:      1:2.0

📝 Why buy?
MACD bullish crossover with rising histogram ...

✅ Key strength: MACD bullish crossover
⚠️ Key risk:    Crude oil weakness
🟢 Confidence: High
```

---

## Configuration guide (config.py)

| Parameter          | Default | Description                                |
|--------------------|---------|--------------------------------------------|
| MAX_STOCKS_PER_DAY | 7       | Max picks per day                          |
| WEIGHT_TECHNICAL   | 0.50    | Technical signal weight in composite score |
| WEIGHT_FUNDAMENTAL | 0.30    | Fundamental weight                         |
| WEIGHT_SENTIMENT   | 0.20    | Sentiment / beta weight                    |
| MIN_RISK_REWARD    | 2.0     | Minimum R:R (1:2 default)                  |
| STOPLOSS_ATR_MULT  | 1.5     | Stoploss = entry − (ATR × 1.5)             |
| MAX_DEBT_EQUITY    | 1.5     | Hard filter: D/E ceiling                   |
| MAX_BETA           | 1.8     | Hard filter: max volatility                |
| ALERT_TIME         | "09:10" | Delivery time (IST)                        |

---

## File structure

```
swing_trader/
├── config.py               # All settings and API keys
├── data_ingestion.py       # Layer 1: Fetch OHLCV + fundamentals
├── signals_technical.py    # Layer 2a: RSI, MACD, EMA, ATR, breakout
├── signals_fundamental.py  # Layer 2b+c: D/E, ROE, sentiment proxy
├── scorer.py               # Layer 3: Composite score + ranking
├── ai_reasoning.py         # Layer 4: Claude-generated rationale
├── alert_delivery.py       # Layer 5: Telegram + console + JSON log
├── main.py                 # Orchestrator + scheduler
├── requirements.txt
├── README.md
└── logs/
    ├── picks_2026-05-20.json   # Daily trade cards (for tracking)
    └── swing_trader.log        # Runtime log
```

---

## Performance tracking

Every day's picks are saved in `logs/picks_YYYY-MM-DD.json`.
You can load these to track win rate, average return, and accuracy over time.

```python
import json, glob
all_picks = []
for f in sorted(glob.glob("logs/picks_*.json")):
    all_picks.extend(json.load(open(f))["picks"])
print(f"Total picks tracked: {len(all_picks)}")
```

---

## Disclaimer

This system is for educational and research purposes. It does not constitute
financial advice. Always do your own analysis before trading. Past signal
performance does not guarantee future returns.
