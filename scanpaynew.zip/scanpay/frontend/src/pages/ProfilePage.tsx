import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAppStore } from '../store/useAppStore'
import api from '../utils/api'
import { LogOut, Bell, MapPin, Lock, CreditCard, ChevronRight, Package } from 'lucide-react'
import toast from 'react-hot-toast'

export default function ProfilePage() {
  const { user, logout } = useAppStore()
  const navigate = useNavigate()
  const [orders, setOrders] = useState<any[]>([])

  useEffect(() => {
    api.get('/orders').then(r => setOrders(r.data.slice(0, 5))).catch(() => {})
  }, [])

  const handleLogout = () => {
    logout()
    navigate('/login')
    toast.success('Signed out')
  }

  const tierColor: Record<string, string> = { Bronze: '#cd7f32', Silver: '#a0b0c0', Gold: '#f0c040', Platinum: '#a49af5' }

  return (
    <div className="page">
      {/* Avatar */}
      <div style={{ textAlign: 'center', marginBottom: 24 }}>
        <div style={{ width: 80, height: 80, borderRadius: 40, background: 'linear-gradient(135deg,var(--accent),#5b8df0)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32, fontWeight: 700, margin: '0 auto 12px' }}>
          {user?.name?.[0]?.toUpperCase() || 'U'}
        </div>
        <h2 style={{ marginBottom: 4 }}>{user?.name}</h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginBottom: 8 }}>{user?.email}</p>
        <div style={{ display: 'flex', gap: 8, justifyContent: 'center', flexWrap: 'wrap' }}>
          <span className="badge badge-purple" style={{ color: tierColor[user?.loyalty_tier || 'Bronze'] }}>
            {user?.loyalty_tier || 'Bronze'} Member
          </span>
          <span className="badge badge-gray">{user?.loyalty_points || 0} points</span>
        </div>
      </div>

      {/* Settings */}
      <div className="card" style={{ marginBottom: 16 }}>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 12, textTransform: 'uppercase', letterSpacing: 1 }}>Account</p>
        {[
          { icon: Bell, label: 'Push Notifications', val: 'On' },
          { icon: MapPin, label: 'Location Access', val: 'Always' },
          { icon: Lock, label: 'Security & PIN', val: 'Enabled' },
          { icon: CreditCard, label: 'Saved Payment Methods', val: '2 cards' },
        ].map(s => {
          const Icon = s.icon
          return (
            <div key={s.label} className="card-hover" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: '1px solid var(--border)', borderRadius: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <Icon size={18} color="var(--text-secondary)" />
                <span style={{ fontSize: 14 }}>{s.label}</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{s.val}</span>
                <ChevronRight size={14} color="var(--text-muted)" />
              </div>
            </div>
          )
        })}
      </div>

      {/* Recent orders */}
      <div className="card" style={{ marginBottom: 16 }}>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 12, textTransform: 'uppercase', letterSpacing: 1 }}>Recent Orders</p>
        {orders.length === 0 && <p style={{ color: 'var(--text-secondary)', fontSize: 13 }}>No orders yet</p>}
        {orders.map((o: any) => (
          <div key={o.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
            <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
              <Package size={16} color="var(--text-secondary)" />
              <div>
                <p style={{ fontSize: 13, fontWeight: 500 }}>{o.order_number}</p>
                <p style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{o.store?.name} · {new Date(o.created_at).toLocaleDateString('en-IN')}</p>
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <p style={{ fontSize: 13, fontWeight: 600 }}>₹{o.total_amount.toLocaleString()}</p>
              <span className={`badge ${o.status === 'paid' ? 'badge-green' : 'badge-amber'}`} style={{ fontSize: 9 }}>{o.status}</span>
            </div>
          </div>
        ))}
      </div>

      <button className="btn btn-danger" onClick={handleLogout} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
        <LogOut size={16} /> Sign Out
      </button>
    </div>
  )
}
