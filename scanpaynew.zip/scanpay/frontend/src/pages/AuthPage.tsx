import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAppStore } from '../store/useAppStore'
import toast from 'react-hot-toast'
import { ShoppingBag, Eye, EyeOff } from 'lucide-react'

export default function AuthPage() {
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [phone, setPhone] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const { login, register } = useAppStore()
  const navigate = useNavigate()

  const submit = async () => {
    if (!email || !password) { toast.error('Please fill in all fields'); return }
    setLoading(true)
    try {
      if (mode === 'login') {
        await login(email, password)
        toast.success('Welcome back!')
      } else {
        if (!name) { toast.error('Name is required'); setLoading(false); return }
        await register(name, email, password, phone)
        toast.success('Account created! 50 welcome points added 🎉')
      }
      navigate('/')
    } catch (err: any) {
      toast.error(err.response?.data?.detail || 'Authentication failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="phone-shell" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', minHeight: '100vh', padding: '32px 24px' }}>
      <div className="animate-slide-up" style={{ textAlign: 'center', marginBottom: 36 }}>
        <div style={{ width: 72, height: 72, background: 'linear-gradient(135deg,#7c6af7,#5b8df0)', borderRadius: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
          <ShoppingBag size={32} color="white" />
        </div>
        <h1>ScanPay</h1>
        <p style={{ color: 'var(--text-secondary)', marginTop: 6, fontSize: 14 }}>Skip the queue — shop smarter</p>
      </div>

      <div style={{ display: 'flex', background: 'var(--bg-surface)', borderRadius: 12, padding: 4, marginBottom: 24, gap: 4 }}>
        {(['login', 'register'] as const).map((m) => (
          <button key={m} onClick={() => setMode(m)} style={{ flex: 1, padding: '10px', border: 'none', borderRadius: 10, background: mode === m ? 'var(--accent)' : 'transparent', color: mode === m ? 'white' : 'var(--text-secondary)', fontWeight: 600, cursor: 'pointer', fontSize: 14, transition: 'all 0.2s', fontFamily: 'inherit' }}>
            {m === 'login' ? 'Sign In' : 'Sign Up'}
          </button>
        ))}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {mode === 'register' && (
          <input className="input" placeholder="Full Name" value={name} onChange={e => setName(e.target.value)} />
        )}
        <input className="input" placeholder="Email address" type="email" value={email} onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key === 'Enter' && submit()} />
        <div style={{ position: 'relative' }}>
          <input className="input" placeholder="Password (min 8 chars)" type={showPass ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} onKeyDown={e => e.key === 'Enter' && submit()} style={{ paddingRight: 44 }} />
          <button onClick={() => setShowPass(!showPass)} style={{ position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', display: 'flex' }}>
            {showPass ? <EyeOff size={18} /> : <Eye size={18} />}
          </button>
        </div>
        {mode === 'register' && (
          <input className="input" placeholder="Phone (optional)" type="tel" value={phone} onChange={e => setPhone(e.target.value)} />
        )}
      </div>

      <button className="btn btn-primary" onClick={submit} disabled={loading} style={{ marginTop: 20 }}>
        {loading ? <span className="animate-pulse">Please wait...</span> : mode === 'login' ? 'Sign In →' : 'Create Account →'}
      </button>

      {mode === 'login' && (
        <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 12, marginTop: 12, cursor: 'pointer' }}>Forgot password?</p>
      )}

      <div style={{ textAlign: 'center', marginTop: 24, color: 'var(--text-muted)', fontSize: 12 }}>
        By continuing you agree to our <span style={{ color: 'var(--accent)' }}>Terms</span> &amp; <span style={{ color: 'var(--accent)' }}>Privacy Policy</span>
      </div>
    </div>
  )
}
