import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAppStore } from '../store/useAppStore'
import { MapPin, QrCode, ShoppingCart, ChevronRight, Star } from 'lucide-react'
import api from '../utils/api'

export default function HomePage() {
  const { user, currentStore, locationStatus, detectNearestStore, setCurrentStore, cart } = useAppStore()
  const [stores, setStores] = useState<any[]>([])
  const [products, setProducts] = useState<any[]>([])
  const navigate = useNavigate()
  const cartCount = cart.reduce((a, i) => a + i.quantity, 0)

  useEffect(() => {
    if (locationStatus === 'idle') detectNearestStore()
    api.get('/stores').then(r => setStores(r.data)).catch(() => {})
    api.get('/products', { params: currentStore ? { store_id: currentStore.id } : {} })
      .then(r => setProducts(r.data)).catch(() => {})
  }, [currentStore])

  const tierColor: Record<string, string> = { Bronze: '#cd7f32', Silver: '#a0b0c0', Gold: '#f0c040', Platinum: '#a49af5' }

  return (
    <div style={{ paddingBottom: 90 }}>
      {/* Hero */}
      <div className="hero-gradient">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
          <div>
            <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginBottom: 4 }}>Welcome back,</p>
            <h2>{user?.name?.split(' ')[0] || 'Shopper'}</h2>
          </div>
          <div style={{ position: 'relative' }}>
            <div onClick={() => navigate('/profile')} style={{ width: 44, height: 44, borderRadius: 22, background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18, fontWeight: 700, cursor: 'pointer' }}>
              {user?.name?.[0]?.toUpperCase() || 'U'}
            </div>
            {cartCount > 0 && <span style={{ position: 'absolute', top: -4, right: -4, background: '#ef4444', color: 'white', borderRadius: 9, width: 18, height: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700 }}>{cartCount}</span>}
          </div>
        </div>

        {/* Points card */}
        <div style={{ background: 'rgba(255,255,255,0.06)', borderRadius: 16, padding: '14px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <p style={{ color: 'var(--text-secondary)', fontSize: 11, marginBottom: 2 }}>Loyalty Points</p>
            <p style={{ fontSize: 28, fontWeight: 800 }}>{user?.loyalty_points?.toLocaleString() || 0}<span style={{ fontSize: 13, color: 'var(--text-secondary)', fontWeight: 400, marginLeft: 4 }}>pts</span></p>
            <span className="badge" style={{ marginTop: 4, fontSize: 10, background: 'rgba(255,255,255,0.1)', color: tierColor[user?.loyalty_tier || 'Bronze'] }}>
              <Star size={10} /> {user?.loyalty_tier || 'Bronze'} Member
            </span>
          </div>
          <div style={{ textAlign: 'right' }}>
            <p style={{ color: 'var(--text-secondary)', fontSize: 11, marginBottom: 4 }}>Cash value</p>
            <p style={{ fontSize: 18, fontWeight: 700, color: 'var(--accent-light)' }}>₹{((user?.loyalty_points || 0) * 0.5).toFixed(0)}</p>
          </div>
        </div>
      </div>

      <div style={{ padding: '16px 20px 0' }}>
        {/* Location bar */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 14, padding: '10px 14px', marginBottom: 16 }}>
          <MapPin size={16} color={locationStatus === 'found' ? 'var(--accent)' : 'var(--text-muted)'} />
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>
              {locationStatus === 'requesting' ? 'Detecting location...' : locationStatus === 'found' ? 'Nearest store detected' : locationStatus === 'error' ? 'Location unavailable' : 'Tap to enable location'}
            </p>
            <p style={{ fontSize: 13, fontWeight: 600 }}>{currentStore ? currentStore.name : 'No store detected'}</p>
          </div>
          {locationStatus === 'found' && <span className="badge badge-green" style={{ fontSize: 10 }}>In range</span>}
          {locationStatus === 'idle' && <button onClick={detectNearestStore} style={{ fontSize: 11, color: 'var(--accent)', background: 'none', border: 'none', cursor: 'pointer', fontWeight: 600, fontFamily: 'inherit' }}>Enable →</button>}
        </div>

        {/* Quick actions */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 20 }}>
          <button className="btn btn-primary" onClick={() => navigate('/scan')} style={{ padding: '16px', gap: 8, borderRadius: 14, fontSize: 14 }}>
            <QrCode size={20} /> Scan Item
          </button>
          <button className="btn btn-secondary" onClick={() => navigate('/cart')} style={{ padding: '16px', gap: 8, borderRadius: 14, fontSize: 14, position: 'relative' }}>
            <ShoppingCart size={20} />
            Cart {cartCount > 0 && `(${cartCount})`}
          </button>
        </div>

        {/* Nearby stores */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <h3>Nearby Stores</h3>
          <span style={{ fontSize: 12, color: 'var(--accent)', cursor: 'pointer' }}>View all</span>
        </div>
        {stores.map(s => (
          <div key={s.id} className="card card-hover" onClick={() => { setCurrentStore(s); }} style={{ marginBottom: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center', border: currentStore?.id === s.id ? '1px solid var(--accent)' : '1px solid var(--border)' }}>
            <div>
              <p style={{ fontWeight: 600, fontSize: 14, marginBottom: 2 }}>{s.name}</p>
              <p style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{s.address}</p>
              <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                <span className="badge badge-purple" style={{ fontSize: 10 }}>{s.category}</span>
                {currentStore?.id === s.id && <span className="badge badge-green" style={{ fontSize: 10 }}>You're here</span>}
              </div>
            </div>
            <ChevronRight size={16} color="var(--text-muted)" />
          </div>
        ))}

        {/* Featured products */}
        {products.length > 0 && <>
          <h3 style={{ marginTop: 20, marginBottom: 12 }}>Featured Items</h3>
          <div style={{ display: 'flex', gap: 10, overflowX: 'auto', paddingBottom: 8 }}>
            {products.slice(0, 6).map((p: any) => (
              <div key={p.id} className="card" style={{ minWidth: 140, flexShrink: 0 }}>
                <div style={{ fontSize: 36, textAlign: 'center', marginBottom: 8 }}>👔</div>
                <p style={{ fontSize: 12, fontWeight: 600, marginBottom: 2, lineHeight: 1.3 }}>{p.name}</p>
                <p style={{ fontSize: 11, color: 'var(--text-secondary)', marginBottom: 4 }}>{p.brand}</p>
                <p style={{ fontSize: 14, fontWeight: 700, color: 'var(--accent)' }}>₹{p.price.toLocaleString()}</p>
                <p style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 2 }}>+{p.loyalty_points_per_unit} pts</p>
              </div>
            ))}
          </div>
        </>}
      </div>
    </div>
  )
}
