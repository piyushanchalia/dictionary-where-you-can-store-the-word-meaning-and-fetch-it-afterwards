import { useEffect, useState } from 'react'
import { useAppStore } from '../store/useAppStore'
import api from '../utils/api'
import { Star, TrendingUp, Gift } from 'lucide-react'

const TIERS = [
  { name: 'Bronze', icon: '🥉', range: '0–199 pts', perks: ['5% bonus points', 'Early sale access'], threshold: 0 },
  { name: 'Silver', icon: '🥈', range: '200–499 pts', perks: ['10% bonus points', 'Priority checkout', 'Free returns'], threshold: 200 },
  { name: 'Gold', icon: '🥇', range: '500–999 pts', perks: ['20% bonus points', 'VIP lounge access', 'Personal stylist'], threshold: 500 },
  { name: 'Platinum', icon: '💎', range: '1000+ pts', perks: ['30% bonus points', 'Concierge service', 'Exclusive events'], threshold: 1000 },
]

export default function LoyaltyPage() {
  const { user } = useAppStore()
  const [summary, setSummary] = useState<any>(null)
  const [history, setHistory] = useState<any[]>([])
  const [tab, setTab] = useState<'overview' | 'history' | 'tiers'>('overview')

  useEffect(() => {
    api.get('/loyalty/summary').then(r => setSummary(r.data)).catch(() => {})
    api.get('/loyalty/history').then(r => setHistory(r.data)).catch(() => {})
  }, [])

  const pts = user?.loyalty_points || 0
  const pctToNext = summary ? Math.min(100, (pts / (summary.points_to_next_tier + pts)) * 100) : 0

  return (
    <div style={{ paddingBottom: 90 }}>
      <div className="hero-gradient" style={{ textAlign: 'center' }}>
        <h2 style={{ marginBottom: 4 }}>Loyalty Rewards</h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginBottom: 20 }}>Earn points every time you shop</p>
        <div style={{ fontSize: 44, marginBottom: 8 }}>🌟</div>
        <p style={{ fontSize: 40, fontWeight: 800, marginBottom: 4 }}>{pts.toLocaleString()}</p>
        <p style={{ color: 'var(--text-secondary)', fontSize: 14, marginBottom: 16 }}>available points</p>

        <div style={{ background: 'rgba(255,255,255,0.06)', borderRadius: 16, padding: '12px 16px', display: 'flex', justifyContent: 'space-around' }}>
          {[['₹' + ((pts * 0.5).toFixed(0)), 'Cash Value'], [user?.loyalty_tier || 'Bronze', 'Your Tier'], [summary?.points_to_next_tier ?? '—', 'To Next Tier']].map(([v, l]) => (
            <div key={l} style={{ textAlign: 'center' }}>
              <p style={{ fontSize: 18, fontWeight: 700 }}>{v}</p>
              <p style={{ color: 'var(--text-secondary)', fontSize: 11 }}>{l}</p>
            </div>
          ))}
        </div>

        {summary?.next_tier && (
          <div style={{ marginTop: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--text-secondary)', marginBottom: 6 }}>
              <span>{user?.loyalty_tier}</span><span>{summary.next_tier}</span>
            </div>
            <div style={{ height: 6, background: 'rgba(255,255,255,0.1)', borderRadius: 3 }}>
              <div style={{ width: `${pctToNext}%`, height: '100%', background: 'linear-gradient(90deg,var(--accent),#5b8df0)', borderRadius: 3, transition: 'width 1s ease' }} />
            </div>
          </div>
        )}
      </div>

      <div style={{ padding: '16px 20px 0' }}>
        <div style={{ display: 'flex', gap: 6, background: 'var(--bg-surface)', padding: 4, borderRadius: 12, marginBottom: 16 }}>
          {(['overview', 'history', 'tiers'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)} style={{ flex: 1, padding: '9px', border: 'none', borderRadius: 9, background: tab === t ? 'var(--accent)' : 'transparent', color: tab === t ? 'white' : 'var(--text-secondary)', fontWeight: 600, cursor: 'pointer', fontSize: 12, transition: 'all 0.2s', fontFamily: 'inherit', textTransform: 'capitalize' }}>
              {t}
            </button>
          ))}
        </div>

        {tab === 'overview' && (
          <div className="animate-fade-in">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
              {[{ label: 'Total Earned', val: `${summary?.total_earned || 0} pts`, icon: TrendingUp }, { label: 'Redeemed', val: `${summary?.total_redeemed || 0} pts`, icon: Gift }, { label: 'Cash Value', val: `₹${(pts * 0.5).toFixed(0)}`, icon: Star }, { label: 'Total Spent', val: `₹${(user?.total_spent || 0).toLocaleString()}`, icon: Star }].map(s => (
                <div key={s.label} className="card" style={{ textAlign: 'center' }}>
                  <p style={{ color: 'var(--text-secondary)', fontSize: 11, marginBottom: 4 }}>{s.label}</p>
                  <p style={{ fontSize: 18, fontWeight: 700 }}>{s.val}</p>
                </div>
              ))}
            </div>
            <div className="card">
              <p style={{ fontWeight: 600, fontSize: 14, marginBottom: 12 }}>Redeem Options</p>
              {[{ label: '₹100 off on ₹999+', cost: 200 }, { label: '₹250 off on ₹1999+', cost: 400 }, { label: 'Free returns pass', cost: 100 }].map(r => (
                <div key={r.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                  <div><p style={{ fontSize: 13, fontWeight: 500 }}>{r.label}</p><p style={{ fontSize: 11, color: 'var(--accent-light)' }}>{r.cost} pts required</p></div>
                  <button style={{ background: pts >= r.cost ? 'rgba(124,106,247,0.2)' : 'var(--bg-surface)', color: pts >= r.cost ? 'var(--accent)' : 'var(--text-muted)', border: 'none', borderRadius: 8, padding: '6px 12px', fontSize: 12, fontWeight: 600, cursor: pts >= r.cost ? 'pointer' : 'default', fontFamily: 'inherit' }}>Redeem</button>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === 'history' && (
          <div className="animate-fade-in">
            {history.length === 0 && <p style={{ color: 'var(--text-secondary)', textAlign: 'center', padding: '20px 0' }}>No transactions yet</p>}
            {history.map((h: any) => (
              <div key={h.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
                <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: h.transaction_type === 'earn' ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>
                    {h.transaction_type === 'earn' ? '⬆️' : '⬇️'}
                  </div>
                  <div>
                    <p style={{ fontSize: 13, fontWeight: 500 }}>{h.description}</p>
                    <p style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{new Date(h.created_at).toLocaleDateString('en-IN')}</p>
                  </div>
                </div>
                <span style={{ fontSize: 14, fontWeight: 700, color: h.transaction_type === 'earn' ? 'var(--success)' : 'var(--error)' }}>
                  {h.transaction_type === 'earn' ? '+' : ''}{h.points} pts
                </span>
              </div>
            ))}
          </div>
        )}

        {tab === 'tiers' && (
          <div className="animate-fade-in">
            {TIERS.map(t => (
              <div key={t.name} className="card" style={{ marginBottom: 10, border: t.name === user?.loyalty_tier ? '1px solid var(--accent)' : '1px solid var(--border)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                  <span style={{ fontSize: 28 }}>{t.icon}</span>
                  <div style={{ flex: 1 }}>
                    <p style={{ fontWeight: 700, fontSize: 15 }}>{t.name}</p>
                    <p style={{ fontSize: 11, color: 'var(--text-secondary)' }}>{t.range}</p>
                  </div>
                  {t.name === user?.loyalty_tier && <span className="badge badge-purple" style={{ fontSize: 10 }}>Current</span>}
                  {pts >= t.threshold && t.name !== user?.loyalty_tier && <span className="badge badge-green" style={{ fontSize: 10 }}>Unlocked</span>}
                </div>
                {t.perks.map(p => <p key={p} style={{ fontSize: 12, color: 'var(--text-secondary)', paddingLeft: 38, marginBottom: 3 }}>• {p}</p>)}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
