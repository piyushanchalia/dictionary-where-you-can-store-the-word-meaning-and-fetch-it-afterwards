import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAppStore } from '../store/useAppStore'
import api from '../utils/api'
import toast from 'react-hot-toast'
import { Trash2, Plus, Minus, ShoppingCart, CreditCard, Smartphone, Building2, Wallet } from 'lucide-react'

const PAYMENT_METHODS = [
  { id: 'upi', label: 'UPI / PhonePe / GPay', sub: 'Instant, no charges', icon: Smartphone },
  { id: 'card', label: 'Credit / Debit Card', sub: 'Visa, Mastercard, RuPay', icon: CreditCard },
  { id: 'wallet', label: 'Paytm Wallet', sub: 'Quick checkout', icon: Wallet },
  { id: 'netbanking', label: 'Net Banking', sub: 'All major banks', icon: Building2 },
]

type Step = 'cart' | 'payment' | 'processing' | 'success'

export default function CartPage() {
  const { cart, updateQty, removeFromCart, clearCart, cartTotal, cartPoints, currentStore, user, refreshUser } = useAppStore()
  const [step, setStep] = useState<Step>('cart')
  const [method, setMethod] = useState('upi')
  const [redeemPoints, setRedeemPoints] = useState(0)
  const [order, setOrder] = useState<any>(null)
  const navigate = useNavigate()

  const subtotal = cartTotal()
  const tax = Math.round(subtotal * 0.18)
  const pointsDiscount = Math.round(redeemPoints * 0.5)
  const total = Math.max(0, Math.round(subtotal + tax - pointsDiscount))
  const pointsEarned = cartPoints()

  if (!cart.length && step === 'cart') {
    return (
      <div className="page" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '70vh', textAlign: 'center' }}>
        <ShoppingCart size={52} color="var(--text-muted)" />
        <h3 style={{ marginTop: 16, marginBottom: 8 }}>Your cart is empty</h3>
        <p style={{ color: 'var(--text-secondary)', fontSize: 14 }}>Scan items to add them here</p>
        <button className="btn btn-primary" onClick={() => navigate('/scan')} style={{ marginTop: 20, width: 'auto', padding: '12px 24px' }}>Start Scanning</button>
      </div>
    )
  }

  if (step === 'processing') {
    return (
      <div className="page" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '70vh', gap: 16 }}>
        <div style={{ width: 60, height: 60, border: '3px solid var(--border)', borderTopColor: 'var(--accent)', borderRadius: 30 }} className="animate-spin" />
        <h3>Processing Payment...</h3>
        <p style={{ color: 'var(--text-secondary)', fontSize: 14 }}>Please don't close this screen</p>
      </div>
    )
  }

  if (step === 'success' && order) {
    return (
      <div className="page animate-slide-up" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
        <div style={{ width: 80, height: 80, background: 'rgba(34,197,94,0.15)', borderRadius: 40, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 40, marginBottom: 16 }}>✅</div>
        <h2 style={{ marginBottom: 8 }}>Payment Successful!</h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: 14, marginBottom: 24 }}>Your receipt has been emailed to {user?.email}</p>

        <div className="card" style={{ width: '100%', marginBottom: 16, textAlign: 'left' }}>
          {[
            ['Order ID', order.order_number],
            ['Store', order.store?.name],
            ['Amount Paid', `₹${order.total_amount.toLocaleString()}`],
            ['Payment Method', method.toUpperCase()],
          ].map(([k, v]) => (
            <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
              <span style={{ color: 'var(--text-secondary)', fontSize: 13 }}>{k}</span>
              <span style={{ fontSize: 13, fontWeight: 500 }}>{v}</span>
            </div>
          ))}
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0 0', alignItems: 'center' }}>
            <span style={{ color: 'var(--accent-light)', fontSize: 13 }}>🌟 Points Earned</span>
            <span style={{ fontSize: 18, fontWeight: 700, color: 'var(--accent-light)' }}>+{order.loyalty_points_earned} pts</span>
          </div>
        </div>

        <div style={{ background: 'linear-gradient(135deg,#1a1060,#0d0d20)', borderRadius: 16, padding: '16px', width: '100%', textAlign: 'center', marginBottom: 20 }}>
          <p style={{ color: 'var(--text-secondary)', fontSize: 12, marginBottom: 4 }}>Estimated queue time saved ⚡</p>
          <p style={{ fontSize: 24, fontWeight: 800, color: 'var(--accent)' }}>~25 minutes</p>
        </div>

        <button className="btn btn-primary" onClick={() => { setStep('cart'); navigate('/') }}>Back to Home</button>
      </div>
    )
  }

  const placeOrder = async () => {
    if (!currentStore) { toast.error('No store detected. Enable location first.'); return }
    setStep('processing')
    try {
      const { data: newOrder } = await api.post('/orders/', {
        store_id: currentStore.id,
        items: cart.map(i => ({ product_id: i.product_id, quantity: i.quantity })),
        redeem_points: redeemPoints,
        payment_method: method,
      })

      // In production: open Razorpay checkout widget
      // For demo/dev: use mock payment endpoint
      if (import.meta.env.VITE_RAZORPAY_KEY_ID?.startsWith('rzp_test_xxx')) {
        const { data: paid } = await api.post(`/orders/${newOrder.id}/pay-mock`)
        clearCart()
        setOrder(paid)
        await refreshUser()
        setStep('success')
      } else {
        // Real Razorpay flow
        const options = {
          key: import.meta.env.VITE_RAZORPAY_KEY_ID,
          amount: Math.round(total * 100),
          currency: 'INR',
          name: 'ScanPay',
          description: `Order ${newOrder.order_number}`,
          order_id: newOrder.razorpay_order_id,
          handler: async (response: any) => {
            const { data: paid } = await api.post('/orders/verify-payment', {
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
              order_id: newOrder.id,
            })
            clearCart()
            setOrder(paid)
            await refreshUser()
            setStep('success')
          },
          prefill: { name: user?.name, email: user?.email },
          theme: { color: '#7c6af7' },
        }
        const rzp = new (window as any).Razorpay(options)
        rzp.open()
        setStep('payment')
      }
    } catch (err: any) {
      toast.error(err.response?.data?.detail || 'Payment failed')
      setStep('cart')
    }
  }

  if (step === 'payment') {
    return (
      <div className="page">
        <button onClick={() => setStep('cart')} style={{ background: 'none', border: 'none', color: 'var(--accent)', cursor: 'pointer', fontSize: 14, display: 'flex', alignItems: 'center', gap: 6, marginBottom: 20, fontFamily: 'inherit', fontWeight: 600 }}>← Back to Cart</button>
        <h2 style={{ marginBottom: 4 }}>Payment Method</h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginBottom: 16 }}>Choose how you'd like to pay</p>

        <div className="card" style={{ marginBottom: 16, display: 'flex', justifyContent: 'space-between', background: 'linear-gradient(135deg,#1a1060,#0d0d20)' }}>
          <div><p style={{ color: 'var(--text-secondary)', fontSize: 12, marginBottom: 4 }}>Amount to Pay</p><p style={{ fontSize: 24, fontWeight: 800 }}>₹{total.toLocaleString()}</p></div>
          <div style={{ textAlign: 'right' }}><p style={{ color: 'var(--text-secondary)', fontSize: 11, marginBottom: 4 }}>Points earned</p><p style={{ fontSize: 16, fontWeight: 700, color: 'var(--accent-light)' }}>+{pointsEarned} pts</p></div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 20 }}>
          {PAYMENT_METHODS.map(m => {
            const Icon = m.icon
            return (
              <div key={m.id} onClick={() => setMethod(m.id)} className="card card-hover" style={{ display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer', border: method === m.id ? '1px solid var(--accent)' : '1px solid var(--border)' }}>
                <div style={{ width: 42, height: 42, borderRadius: 12, background: method === m.id ? 'rgba(124,106,247,0.2)' : 'var(--bg-surface)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Icon size={20} color={method === m.id ? 'var(--accent)' : 'var(--text-muted)'} />
                </div>
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: 14, fontWeight: 600 }}>{m.label}</p>
                  <p style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{m.sub}</p>
                </div>
                <div style={{ width: 18, height: 18, borderRadius: 9, border: `2px solid ${method === m.id ? 'var(--accent)' : 'var(--text-muted)'}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {method === m.id && <div style={{ width: 8, height: 8, borderRadius: 4, background: 'var(--accent)' }} />}
                </div>
              </div>
            )
          })}
        </div>

        <button className="btn btn-primary" onClick={placeOrder}>Pay ₹{total.toLocaleString()} Now →</button>
      </div>
    )
  }

  return (
    <div className="page">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h2>My Cart</h2>
        <span className="badge badge-purple">{cart.reduce((a, i) => a + i.quantity, 0)} items</span>
      </div>

      {cart.map(item => (
        <div key={item.product_id} className="card" style={{ marginBottom: 10, display: 'flex', gap: 12, alignItems: 'center' }}>
          <div style={{ fontSize: 36 }}>👔</div>
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: 13, fontWeight: 600, marginBottom: 2 }}>{item.name}</p>
            <p style={{ fontSize: 11, color: 'var(--text-secondary)', marginBottom: 6 }}>{item.brand}</p>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 15, fontWeight: 700, color: 'var(--accent)' }}>₹{(item.price * item.quantity).toLocaleString()}</span>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <button className="btn-icon" onClick={() => updateQty(item.product_id, item.quantity - 1)} style={{ width: 28, height: 28, borderRadius: 8, padding: 0 }}><Minus size={12} /></button>
                <span style={{ fontSize: 14, fontWeight: 600, minWidth: 16, textAlign: 'center' }}>{item.quantity}</span>
                <button className="btn-icon" onClick={() => updateQty(item.product_id, item.quantity + 1)} style={{ width: 28, height: 28, borderRadius: 8, padding: 0 }}><Plus size={12} /></button>
                <button className="btn-icon" onClick={() => removeFromCart(item.product_id)} style={{ width: 28, height: 28, borderRadius: 8, padding: 0, borderColor: 'rgba(239,68,68,0.3)' }}><Trash2 size={12} color="var(--error)" /></button>
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Loyalty redemption */}
      {(user?.loyalty_points || 0) > 0 && (
        <div className="card" style={{ marginBottom: 16 }}>
          <p style={{ fontSize: 13, fontWeight: 600, marginBottom: 8, color: 'var(--accent-light)' }}>🌟 Redeem Loyalty Points</p>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <input type="range" min={0} max={Math.min(user?.loyalty_points || 0, Math.floor(total / 0.5))} value={redeemPoints} onChange={e => setRedeemPoints(Number(e.target.value))} style={{ flex: 1, accentColor: 'var(--accent)' }} />
            <span style={{ fontSize: 13, fontWeight: 600, minWidth: 60 }}>{redeemPoints} pts</span>
          </div>
          {redeemPoints > 0 && <p style={{ fontSize: 12, color: 'var(--success)', marginTop: 6 }}>Saving ₹{pointsDiscount}</p>}
        </div>
      )}

      {/* Order summary */}
      <div className="card" style={{ marginBottom: 16 }}>
        {[['Subtotal', `₹${subtotal.toLocaleString()}`], ['Tax (18% GST)', `₹${tax.toLocaleString()}`]].map(([k, v]) => (
          <div key={k} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ color: 'var(--text-secondary)', fontSize: 13 }}>{k}</span>
            <span style={{ fontSize: 13 }}>{v}</span>
          </div>
        ))}
        {redeemPoints > 0 && <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}><span style={{ color: 'var(--success)', fontSize: 13 }}>Points Discount</span><span style={{ fontSize: 13, color: 'var(--success)' }}>-₹{pointsDiscount}</span></div>}
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
          <span style={{ color: 'var(--accent-light)', fontSize: 13 }}>🌟 Points to earn</span>
          <span style={{ fontSize: 13, color: 'var(--accent-light)' }}>+{pointsEarned} pts</span>
        </div>
        <div className="divider" />
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontWeight: 700, fontSize: 16 }}>Total</span>
          <span style={{ fontWeight: 700, fontSize: 16, color: 'var(--accent)' }}>₹{total.toLocaleString()}</span>
        </div>
      </div>

      <button className="btn btn-primary" onClick={() => setStep('payment')}>
        Proceed to Pay ₹{total.toLocaleString()} →
      </button>
    </div>
  )
}
