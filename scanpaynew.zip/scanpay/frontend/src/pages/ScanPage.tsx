import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Html5Qrcode } from 'html5-qrcode'
import { useAppStore } from '../store/useAppStore'
import api from '../utils/api'
import toast from 'react-hot-toast'
import { Camera, X, ShoppingCartIcon, RotateCcw } from 'lucide-react'

interface ScannedProduct {
  id: string
  sku: string
  name: string
  brand: string
  category: string
  price: number
  loyalty_points_per_unit: number
  stock_quantity: number
}

export default function ScanPage() {
  const [scanning, setScanning] = useState(false)
  const [scannedProduct, setScannedProduct] = useState<ScannedProduct | null>(null)
  const [cameraError, setCameraError] = useState('')
  const scannerRef = useRef<Html5Qrcode | null>(null)
  const { addToCart, currentStore, cart } = useAppStore()
  const navigate = useNavigate()

  const stopScanner = async () => {
    if (scannerRef.current?.isScanning) {
      await scannerRef.current.stop()
      await scannerRef.current.clear()
    }
    setScanning(false)
  }

  const startScanner = async () => {
    try {
      setCameraError('')
      const cameras = await Html5Qrcode.getCameras()
      if (!cameras.length) { setCameraError('No camera found on device'); return }

      scannerRef.current = new Html5Qrcode('qr-reader')
      await scannerRef.current.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 220, height: 220 } },
        async (decodedText) => {
          await stopScanner()
          await fetchProduct(decodedText)
        },
        () => {}
      )
      setScanning(true)
    } catch (err: any) {
      setCameraError('Camera permission denied. Use demo scan below.')
      setScanning(false)
    }
  }

  useEffect(() => {
    return () => {
      // useEffect cleanup must be synchronous; fire-and-forget the async stop
      if (scannerRef.current?.isScanning) {
        scannerRef.current.stop().catch(() => {})
      }
    }
  }, [])

  const fetchProduct = async (productId: string) => {
    try {
      const { data } = await api.post('/products/scan', {
        product_id: productId,
        latitude: null,
        longitude: null,
      })
      setScannedProduct(data.product)
    } catch {
      toast.error('Product not found. Scan again.')
    }
  }

  const demoScan = async () => {
    try {
      const { data: products } = await api.get('/products', {
        params: currentStore ? { store_id: currentStore.id } : {},
      })
      if (!products.length) { toast.error('No products available'); return }
      const random = products[Math.floor(Math.random() * products.length)]
      const { data } = await api.post('/products/scan', { product_id: random.id })
      setScannedProduct(data.product)
      toast.success('QR scanned!')
    } catch {
      toast.error('Scan failed')
    }
  }

  const handleAddToCart = () => {
    if (!scannedProduct) return
    addToCart({
      product_id: scannedProduct.id,
      name: scannedProduct.name,
      brand: scannedProduct.brand,
      price: scannedProduct.price,
      loyalty_points_per_unit: scannedProduct.loyalty_points_per_unit,
    })
    toast.success(`${scannedProduct.name} added to cart!`)
    setScannedProduct(null)
  }

  const inCart = scannedProduct ? cart.find(i => i.product_id === scannedProduct.id) : null

  if (scannedProduct) {
    return (
      <div className="page animate-slide-up">
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <div style={{ width: 64, height: 64, background: 'rgba(34,197,94,0.15)', borderRadius: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px', fontSize: 28 }}>✅</div>
          <h2>Item Found!</h2>
          <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginTop: 4 }}>QR code scanned successfully</p>
        </div>

        <div className="card" style={{ marginBottom: 20 }}>
          <div style={{ textAlign: 'center', fontSize: 52, marginBottom: 12 }}>👔</div>
          <h3 style={{ marginBottom: 4 }}>{scannedProduct.name}</h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginBottom: 12 }}>{scannedProduct.brand} · {scannedProduct.category}</p>
          <div className="divider" />
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 }}>
            <span style={{ fontSize: 24, fontWeight: 800, color: 'var(--accent)' }}>₹{scannedProduct.price.toLocaleString()}</span>
            <div style={{ display: 'flex', gap: 6 }}>
              <span className="badge badge-green">In Stock ({scannedProduct.stock_quantity})</span>
            </div>
          </div>
          <div style={{ background: 'rgba(124,106,247,0.1)', borderRadius: 10, padding: '8px 12px', marginTop: 12, display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Loyalty points earned</span>
            <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--accent-light)' }}>+{scannedProduct.loyalty_points_per_unit} pts</span>
          </div>
          {inCart && <div style={{ background: 'rgba(245,158,11,0.1)', borderRadius: 10, padding: '8px 12px', marginTop: 8, textAlign: 'center', fontSize: 12, color: '#fbbf24' }}>Already in cart ×{inCart.quantity}</div>}
        </div>

        <button className="btn btn-primary" onClick={handleAddToCart} style={{ marginBottom: 10 }}>
          <ShoppingCartIcon size={18} /> Add to Cart
        </button>
        <button className="btn btn-secondary" onClick={() => setScannedProduct(null)}>
          <RotateCcw size={16} /> Scan Another Item
        </button>
      </div>
    )
  }

  return (
    <div className="page">
      <div className="page-header">
        <h2>Scan QR Code</h2>
        <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginTop: 4 }}>Point camera at the tag on any clothing item</p>
      </div>

      <div style={{ position: 'relative', background: '#000', borderRadius: 20, overflow: 'hidden', height: 280, marginBottom: 16 }}>
        <div id="qr-reader" style={{ width: '100%', height: '100%' }} />
        {!scanning && (
          <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg,#0d0d1a,#1a1030)' }}>
            <Camera size={48} color="var(--text-muted)" />
            <p style={{ color: 'var(--text-muted)', fontSize: 13, marginTop: 12 }}>Tap below to start scanning</p>
          </div>
        )}
        {scanning && (
          <div className="scanner-overlay">
            <div className="scan-frame">
              <div className="scan-corner tl" /><div className="scan-corner tr" />
              <div className="scan-corner bl" /><div className="scan-corner br" />
              <div className="scan-line" />
            </div>
          </div>
        )}
      </div>

      {cameraError && <p style={{ color: 'var(--warning)', fontSize: 12, textAlign: 'center', marginBottom: 12 }}>{cameraError}</p>}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 10 }}>
        {!scanning ? (
          <button className="btn btn-primary" onClick={startScanner}>
            <Camera size={18} /> Open Camera
          </button>
        ) : (
          <button className="btn btn-danger" onClick={stopScanner}>
            <X size={18} /> Stop Scanning
          </button>
        )}
        <button className="btn-icon" onClick={demoScan} title="Demo scan" style={{ padding: '14px 16px', borderRadius: 12, fontSize: 13, gap: 6, display: 'flex', alignItems: 'center', color: 'var(--accent)', borderColor: 'var(--accent)' }}>
          Demo
        </button>
      </div>

      <div style={{ marginTop: 20 }}>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 8 }}>How it works:</p>
        {['Point your camera at the QR tag on a clothing item', 'Product info appears automatically', 'Add to cart and pay all at once'].map((s, i) => (
          <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', marginBottom: 8 }}>
            <div style={{ width: 22, height: 22, borderRadius: 11, background: 'rgba(124,106,247,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: 'var(--accent)', flexShrink: 0, marginTop: 1 }}>{i + 1}</div>
            <p style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.5 }}>{s}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
