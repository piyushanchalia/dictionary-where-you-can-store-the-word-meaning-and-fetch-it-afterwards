import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { useAppStore } from './store/useAppStore'
import AuthPage from './pages/AuthPage'
import HomePage from './pages/HomePage'
import ScanPage from './pages/ScanPage'
import CartPage from './pages/CartPage'
import LoyaltyPage from './pages/LoyaltyPage'
import ProfilePage from './pages/ProfilePage'
import BottomNav from './components/BottomNav'
import './index.css'

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAppStore()
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" replace />
}

function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="phone-shell">
      {children}
      <BottomNav />
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <Toaster
        position="top-center"
        toastOptions={{
          style: { background: '#1e1e30', color: '#f0eff8', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 12, fontSize: 14 },
          success: { iconTheme: { primary: '#22c55e', secondary: '#f0eff8' } },
          error: { iconTheme: { primary: '#ef4444', secondary: '#f0eff8' } },
        }}
      />
      <Routes>
        <Route path="/login" element={<AuthPage />} />
        <Route path="/" element={<ProtectedRoute><AppLayout><HomePage /></AppLayout></ProtectedRoute>} />
        <Route path="/scan" element={<ProtectedRoute><AppLayout><ScanPage /></AppLayout></ProtectedRoute>} />
        <Route path="/cart" element={<ProtectedRoute><AppLayout><CartPage /></AppLayout></ProtectedRoute>} />
        <Route path="/loyalty" element={<ProtectedRoute><AppLayout><LoyaltyPage /></AppLayout></ProtectedRoute>} />
        <Route path="/profile" element={<ProtectedRoute><AppLayout><ProfilePage /></AppLayout></ProtectedRoute>} />
      </Routes>
    </BrowserRouter>
  )
}
