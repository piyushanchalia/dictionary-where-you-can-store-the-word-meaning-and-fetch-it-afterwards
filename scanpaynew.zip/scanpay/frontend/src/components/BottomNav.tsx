import { useNavigate, useLocation } from 'react-router-dom'
import { Home, QrCode, ShoppingCart, Star, User } from 'lucide-react'
import { useAppStore } from '../store/useAppStore'

const NAV_ITEMS = [
  { path: '/', icon: Home, label: 'Home' },
  { path: '/scan', icon: QrCode, label: 'Scan' },
  { path: '/cart', icon: ShoppingCart, label: 'Cart' },
  { path: '/loyalty', icon: Star, label: 'Points' },
  { path: '/profile', icon: User, label: 'Profile' },
]

export default function BottomNav() {
  const navigate = useNavigate()
  const location = useLocation()
  const { cart } = useAppStore()
  const cartCount = cart.reduce((a, i) => a + i.quantity, 0)

  return (
    <nav className="bottom-nav">
      {NAV_ITEMS.map(({ path, icon: Icon, label }) => {
        const active = location.pathname === path
        return (
          <div key={path} className={`nav-item ${active ? 'active' : ''}`} onClick={() => navigate(path)}>
            <div style={{ position: 'relative' }}>
              <Icon size={22} strokeWidth={active ? 2.2 : 1.8} />
              {path === '/cart' && cartCount > 0 && (
                <span style={{ position: 'absolute', top: -6, right: -8, background: '#ef4444', color: 'white', borderRadius: 8, width: 16, height: 16, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 9, fontWeight: 700 }}>
                  {cartCount}
                </span>
              )}
            </div>
            <span>{label}</span>
          </div>
        )
      })}
    </nav>
  )
}
