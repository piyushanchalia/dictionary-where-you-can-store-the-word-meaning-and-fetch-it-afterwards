import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import api from '../utils/api'

export interface User {
  id: string
  name: string
  email: string
  phone?: string
  loyalty_points: number
  loyalty_tier: string
  total_spent: number
}

export interface CartItem {
  product_id: string
  quantity: number
  name: string
  brand: string
  price: number
  image_url?: string
  loyalty_points_per_unit: number
}

export interface Store {
  id: string
  name: string
  address: string
  city: string
  latitude: number
  longitude: number
  category: string
}

interface AppState {
  // Auth
  user: User | null
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, password: string, phone?: string) => Promise<void>
  logout: () => void
  refreshUser: () => Promise<void>

  // Cart
  cart: CartItem[]
  addToCart: (item: Omit<CartItem, 'quantity'>) => void
  removeFromCart: (product_id: string) => void
  updateQty: (product_id: string, qty: number) => void
  clearCart: () => void
  cartTotal: () => number
  cartPoints: () => number

  // Geo
  currentStore: Store | null
  locationStatus: 'idle' | 'requesting' | 'found' | 'error'
  setCurrentStore: (store: Store) => void
  detectNearestStore: () => Promise<void>
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,

      login: async (email, password) => {
        const { data } = await api.post('/auth/login', { email, password })
        localStorage.setItem('access_token', data.access_token)
        localStorage.setItem('refresh_token', data.refresh_token)
        const me = await api.get('/auth/me')
        set({ user: me.data, isAuthenticated: true })
      },

      register: async (name, email, password, phone) => {
        const { data } = await api.post('/auth/register', { name, email, password, phone })
        localStorage.setItem('access_token', data.access_token)
        localStorage.setItem('refresh_token', data.refresh_token)
        const me = await api.get('/auth/me')
        set({ user: me.data, isAuthenticated: true })
      },

      logout: () => {
        localStorage.removeItem('access_token')
        localStorage.removeItem('refresh_token')
        set({ user: null, isAuthenticated: false, cart: [], currentStore: null, locationStatus: 'idle' })
      },

      refreshUser: async () => {
        try {
          const { data } = await api.get('/auth/me')
          set({ user: data })
        } catch {}
      },

      // Cart
      cart: [],
      addToCart: (item) => {
        set((state) => {
          const existing = state.cart.find((i) => i.product_id === item.product_id)
          if (existing) {
            return { cart: state.cart.map((i) => i.product_id === item.product_id ? { ...i, quantity: i.quantity + 1 } : i) }
          }
          return { cart: [...state.cart, { ...item, quantity: 1 }] }
        })
      },
      removeFromCart: (product_id) => set((state) => ({ cart: state.cart.filter((i) => i.product_id !== product_id) })),
      updateQty: (product_id, qty) => {
        if (qty < 1) { get().removeFromCart(product_id); return }
        set((state) => ({ cart: state.cart.map((i) => i.product_id === product_id ? { ...i, quantity: qty } : i) }))
      },
      clearCart: () => set({ cart: [] }),
      cartTotal: () => get().cart.reduce((sum, i) => sum + i.price * i.quantity, 0),
      cartPoints: () => get().cart.reduce((sum, i) => sum + i.loyalty_points_per_unit * i.quantity, 0),

      // Geo
      currentStore: null,
      locationStatus: 'idle',
      setCurrentStore: (store) => set({ currentStore: store }),
      detectNearestStore: async () => {
        set({ locationStatus: 'requesting' })
        if (!navigator.geolocation) { set({ locationStatus: 'error' }); return }
        navigator.geolocation.getCurrentPosition(
          async (pos) => {
            try {
              const { data } = await api.post('/stores/detect', {
                latitude: pos.coords.latitude,
                longitude: pos.coords.longitude,
              })
              set({ currentStore: data.store, locationStatus: 'found' })
            } catch {
              set({ locationStatus: 'error' })
            }
          },
          () => set({ locationStatus: 'error' })
        )
      },
    }),
    {
      name: 'scanpay-store',
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated, cart: state.cart }),
    }
  )
)
