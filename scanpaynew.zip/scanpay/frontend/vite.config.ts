import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Inside Docker the backend is reachable at http://backend:8000
// Outside Docker (local dev) it's at http://localhost:8000
const backendUrl = process.env.BACKEND_URL || 'http://localhost:8000'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: '0.0.0.0',
    proxy: {
      '/api': {
        target: backendUrl,
        changeOrigin: true,
      },
    },
  },
})
