# 🛍️ ScanPay — Skip the Queue

A production-grade retail self-checkout application. Customers scan QR codes on clothing tags, build a cart on their phone, and pay instantly — no billing queue.

## Features

| Feature | Details |
|---|---|
| **Auth** | JWT with refresh tokens, bcrypt password hashing |
| **Geolocation** | GPS-based nearest store detection with haversine distance |
| **QR Scanner** | Real camera scanning (html5-qrcode) + server-side QR generation |
| **Cart** | Multi-item, real-time quantity updates, persisted in Zustand |
| **Payments** | Razorpay integration with signature verification |
| **Loyalty** | Points on every purchase, 4-tier system, in-app redemption |
| **Database** | PostgreSQL + async SQLAlchemy |
| **API** | FastAPI with full OpenAPI docs at `/docs` |

---

## Quick Start (Docker — recommended)

```bash
# 1. Clone and enter the project
cd scanpay

# 2. Copy env files
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env

# 3. Start everything
docker-compose up --build

# 4. Seed database (in a new terminal)
docker-compose exec backend python seed.py
```

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:8000
- **API Docs**: http://localhost:8000/docs

---

## Manual Setup (without Docker)

### Prerequisites
- Python 3.12+
- Node.js 20+
- PostgreSQL 15+

### Backend

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your PostgreSQL credentials and secret key

# Start the API server
uvicorn app.main:app --reload --port 8000

# In another terminal, seed the database
python seed.py
```

### Frontend

```bash
cd frontend

npm install

# Configure environment
cp .env.example .env
# Edit .env — set VITE_API_URL=/api/v1  (relative path, Vite proxy handles routing)

npm run dev
```

---

## Razorpay Setup (for real payments)

1. Sign up at https://dashboard.razorpay.com
2. Get your **Test Key ID** and **Test Key Secret**
3. Add to `backend/.env`:
   ```
   RAZORPAY_KEY_ID=rzp_test_your_key_id
   RAZORPAY_KEY_SECRET=your_key_secret
   ```
4. Add to `frontend/.env`:
   ```
   VITE_RAZORPAY_KEY_ID=rzp_test_your_key_id
   ```

Without Razorpay keys, the app uses a **mock payment** endpoint for development.

---

## Project Structure

```
scanpay/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   ├── auth.py       # Register, login, refresh, /me
│   │   │   ├── stores.py     # List stores, detect nearest
│   │   │   ├── products.py   # List, scan, QR generation
│   │   │   ├── orders.py     # Create order, verify payment
│   │   │   └── loyalty.py    # Summary, history
│   │   ├── models/
│   │   │   └── __init__.py   # SQLAlchemy ORM models
│   │   ├── utils/
│   │   │   ├── auth.py       # JWT, bcrypt
│   │   │   ├── qr.py         # QR code generation
│   │   │   ├── geo.py        # Haversine distance
│   │   │   ├── schemas.py    # Pydantic request/response models
│   │   │   └── dependencies.py  # FastAPI auth dependency
│   │   ├── config.py         # Pydantic settings
│   │   ├── database.py       # Async SQLAlchemy engine
│   │   └── main.py           # FastAPI app + CORS
│   ├── seed.py               # Database seeder
│   ├── Dockerfile
│   └── requirements.txt
│
├── frontend/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── AuthPage.tsx     # Login / Register
│   │   │   ├── HomePage.tsx     # Dashboard + geo store detection
│   │   │   ├── ScanPage.tsx     # Camera QR scanner
│   │   │   ├── CartPage.tsx     # Cart + checkout + payment
│   │   │   ├── LoyaltyPage.tsx  # Points dashboard
│   │   │   └── ProfilePage.tsx  # User profile + order history
│   │   ├── components/
│   │   │   └── BottomNav.tsx    # Tab navigation
│   │   ├── store/
│   │   │   └── useAppStore.ts   # Zustand global state
│   │   ├── utils/
│   │   │   └── api.ts           # Axios client + token refresh
│   │   ├── App.tsx              # Router
│   │   ├── main.tsx
│   │   └── index.css            # Design system
│   ├── Dockerfile
│   └── package.json
│
├── docker-compose.yml
└── README.md
```

---

## API Endpoints

| Method | Route | Auth | Description |
|--------|-------|------|-------------|
| POST | `/api/v1/auth/register` | ❌ | Create account |
| POST | `/api/v1/auth/login` | ❌ | Login |
| POST | `/api/v1/auth/refresh` | ❌ | Refresh tokens |
| GET | `/api/v1/auth/me` | ✅ | Current user |
| GET | `/api/v1/stores/` | ❌ | List all stores |
| POST | `/api/v1/stores/detect` | ✅ | Nearest store by GPS |
| GET | `/api/v1/products/` | ❌ | List products (filter by store) |
| POST | `/api/v1/products/scan` | ✅ | Log QR scan, get product |
| GET | `/api/v1/products/qr/{id}` | ❌ | QR code PNG image |
| POST | `/api/v1/orders/` | ✅ | Create order |
| POST | `/api/v1/orders/verify-payment` | ✅ | Verify Razorpay |
| POST | `/api/v1/orders/{id}/pay-mock` | ✅ | Dev: mock payment |
| GET | `/api/v1/orders/` | ✅ | Order history |
| GET | `/api/v1/loyalty/summary` | ✅ | Points summary |
| GET | `/api/v1/loyalty/history` | ✅ | Transaction history |

---

## Loyalty Tier System

| Tier | Points | Bonus | Perks |
|------|--------|-------|-------|
| 🥉 Bronze | 0–199 | +5% | Early sale access |
| 🥈 Silver | 200–499 | +10% | Priority checkout, free returns |
| 🥇 Gold | 500–999 | +20% | VIP lounge, personal stylist |
| 💎 Platinum | 1000+ | +30% | Concierge, exclusive events |

1 loyalty point = ₹0.50 cash value when redeemed.

---

## Generating QR Tags for Physical Items

After seeding, each product gets a QR code URL. To print QR tags:

```bash
# Get all products with QR URLs
curl http://localhost:8000/api/v1/products/ | python -m json.tool

# Download a specific product's QR as PNG
curl http://localhost:8000/api/v1/products/qr/{product_id} -o tag.png
```

Print and attach to clothing items. When a customer scans one with the app camera, it fetches the product info instantly.

---

## Production Deployment Checklist

- [ ] Set `SECRET_KEY` to a strong random value: `openssl rand -hex 32`
- [ ] Switch `ENVIRONMENT=production` in backend `.env`
- [ ] Enable HTTPS (use Nginx + Certbot or a managed service)
- [ ] Switch to Razorpay live keys
- [ ] Set up proper `FRONTEND_URL` in backend CORS
- [ ] Use a managed PostgreSQL (RDS, Supabase, etc.)
- [ ] Set up database backups
- [ ] Add rate limiting (slowapi) for auth routes
- [ ] Configure proper logging and monitoring (Sentry, etc.)
