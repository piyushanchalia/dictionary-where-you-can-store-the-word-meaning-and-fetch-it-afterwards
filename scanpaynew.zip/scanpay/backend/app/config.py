from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    DATABASE_URL: str
    SYNC_DATABASE_URL: str
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    RAZORPAY_KEY_ID: str = ""
    RAZORPAY_KEY_SECRET: str = ""
    APP_NAME: str = "ScanPay"
    FRONTEND_URL: str = "http://localhost:5173"
    ENVIRONMENT: str = "development"
    QR_BASE_URL: str = "http://localhost:8000/api/v1/products/qr"

    class Config:
        env_file = ".env"


settings = Settings()
