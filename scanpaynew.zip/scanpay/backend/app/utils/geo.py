import math
from typing import Optional


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate great-circle distance between two points in meters."""
    R = 6371000  # Earth radius in meters
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)

    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


def is_within_store(
    user_lat: float,
    user_lon: float,
    store_lat: float,
    store_lon: float,
    radius_meters: int = 100,
) -> bool:
    distance = haversine_distance(user_lat, user_lon, store_lat, store_lon)
    return distance <= radius_meters


def find_nearest_store(user_lat: float, user_lon: float, stores: list) -> Optional[dict]:
    """Return the nearest store and its distance."""
    if not stores:
        return None

    nearest = None
    min_distance = float("inf")

    for store in stores:
        dist = haversine_distance(user_lat, user_lon, store.latitude, store.longitude)
        if dist < min_distance:
            min_distance = dist
            nearest = {"store": store, "distance_meters": round(dist)}

    return nearest
