import qrcode
import io
import base64
from app.config import settings

# StyledPilImage available in qrcode >= 7.4 — try import with graceful fallback
try:
    from qrcode.image.styledpil import StyledPilImage
    from qrcode.image.styles.moduledrawers.base import BaseModuleDrawer  # noqa
    from qrcode.image.styles.moduledrawers import RoundedModuleDrawer
    _STYLED = True
except ImportError:
    _STYLED = False


def _make_qr(data: str) -> qrcode.QRCode:
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=10,
        border=4,
    )
    qr.add_data(data)
    qr.make(fit=True)
    return qr


def generate_qr_code_base64(product_id: str, sku: str) -> str:
    """Generate a QR code for a product and return as base64 PNG string."""
    qr = _make_qr(f"{settings.QR_BASE_URL}/{product_id}")

    if _STYLED:
        img = qr.make_image(
            image_factory=StyledPilImage,
            module_drawer=RoundedModuleDrawer(),
            fill_color="#1a0a40",
            back_color="white",
        )
    else:
        img = qr.make_image(fill_color="#1a0a40", back_color="white")

    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    buffer.seek(0)
    return f"data:image/png;base64,{base64.b64encode(buffer.getvalue()).decode()}"


def generate_qr_bytes(product_id: str) -> bytes:
    """Generate QR code and return raw PNG bytes for file serving."""
    qr = _make_qr(f"{settings.QR_BASE_URL}/{product_id}")
    img = qr.make_image(fill_color="#1a0a40", back_color="white")
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    buffer.seek(0)
    return buffer.getvalue()
