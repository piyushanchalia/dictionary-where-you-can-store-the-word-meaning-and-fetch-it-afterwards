from pydantic import BaseModel, EmailStr, Field, field_validator
from typing import Optional
from decimal import Decimal
from datetime import datetime
from uuid import UUID
from app.models import LoyaltyTier, OrderStatus, TransactionType


# ── Auth ──────────────────────────────────────────────────────────────────────

class UserRegister(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr
    password: str = Field(..., min_length=8)
    phone: Optional[str] = None

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if not any(c.isdigit() for c in v):
            raise ValueError("Password must contain at least one digit")
        return v


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshRequest(BaseModel):
    refresh_token: str


# ── User ──────────────────────────────────────────────────────────────────────

class UserResponse(BaseModel):
    id: UUID
    name: str
    email: str
    phone: Optional[str]
    loyalty_points: int
    loyalty_tier: LoyaltyTier
    total_spent: Decimal
    created_at: datetime

    model_config = {"from_attributes": True}


class UserUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=2, max_length=100)
    phone: Optional[str] = None


# ── Store ─────────────────────────────────────────────────────────────────────

class StoreResponse(BaseModel):
    id: UUID
    name: str
    address: str
    city: str
    latitude: float
    longitude: float
    radius_meters: int
    category: str

    model_config = {"from_attributes": True}


class NearestStoreResponse(BaseModel):
    store: StoreResponse
    distance_meters: int
    is_within_range: bool


class StoreDetectRequest(BaseModel):
    latitude: float = Field(..., ge=-90, le=90)
    longitude: float = Field(..., ge=-180, le=180)


# ── Product ───────────────────────────────────────────────────────────────────

class ProductResponse(BaseModel):
    id: UUID
    sku: str
    name: str
    brand: str
    category: str
    description: Optional[str]
    price: Decimal
    stock_quantity: int
    image_url: Optional[str]
    qr_code_url: Optional[str]
    store_id: UUID
    loyalty_points_per_unit: int

    model_config = {"from_attributes": True}


class ProductCreate(BaseModel):
    sku: str = Field(..., min_length=3, max_length=50)
    name: str = Field(..., min_length=2, max_length=200)
    brand: str = Field(..., min_length=1, max_length=100)
    category: str
    description: Optional[str] = None
    price: float = Field(..., gt=0)
    stock_quantity: int = Field(..., ge=0)
    store_id: UUID
    loyalty_points_per_unit: Optional[int] = None


class ScanLogCreate(BaseModel):
    product_id: UUID
    latitude: Optional[float] = None
    longitude: Optional[float] = None


# ── Cart & Orders ─────────────────────────────────────────────────────────────

class CartItem(BaseModel):
    product_id: UUID
    quantity: int = Field(..., ge=1, le=99)


class CreateOrderRequest(BaseModel):
    store_id: UUID
    items: list[CartItem] = Field(..., min_length=1)
    redeem_points: int = Field(0, ge=0)
    payment_method: Optional[str] = None


class OrderItemResponse(BaseModel):
    id: UUID
    product_id: UUID
    quantity: int
    unit_price: Decimal
    subtotal: Decimal
    loyalty_points: int
    product: ProductResponse

    model_config = {"from_attributes": True}


class OrderResponse(BaseModel):
    id: UUID
    order_number: str
    user_id: UUID
    store_id: UUID
    subtotal: Decimal
    tax_amount: Decimal
    discount_amount: Decimal
    total_amount: Decimal
    loyalty_points_earned: int
    loyalty_points_redeemed: int
    status: OrderStatus
    payment_method: Optional[str]
    razorpay_order_id: Optional[str]
    created_at: datetime
    paid_at: Optional[datetime]
    items: list[OrderItemResponse]
    store: StoreResponse

    model_config = {"from_attributes": True}


class PaymentVerifyRequest(BaseModel):
    razorpay_order_id: str
    razorpay_payment_id: str
    razorpay_signature: str
    order_id: UUID


# ── Loyalty ───────────────────────────────────────────────────────────────────

class LoyaltyTransactionResponse(BaseModel):
    id: UUID
    transaction_type: TransactionType
    points: int
    balance_after: int
    description: str
    created_at: datetime

    model_config = {"from_attributes": True}


class LoyaltySummary(BaseModel):
    current_points: int
    current_tier: LoyaltyTier
    total_earned: int
    total_redeemed: int
    points_to_next_tier: int
    next_tier: Optional[str]
    cashback_value: float


class RedeemPointsRequest(BaseModel):
    points: int = Field(..., gt=0)
    order_id: Optional[UUID] = None
