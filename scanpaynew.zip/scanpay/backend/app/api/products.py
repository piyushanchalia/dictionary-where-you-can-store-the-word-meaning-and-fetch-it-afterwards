from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from uuid import UUID
from app.database import get_db
from app.models import Product, Store, ScanLog, User
from app.utils.schemas import ProductResponse, ProductCreate, ScanLogCreate
from app.utils.dependencies import get_current_user
from app.utils.qr import generate_qr_bytes, generate_qr_code_base64

router = APIRouter(prefix="/products", tags=["Products"])


@router.get("/", response_model=list[ProductResponse])
async def list_products(
    store_id: str | None = Query(None),
    category: str | None = Query(None),
    db: AsyncSession = Depends(get_db),
):
    query = select(Product).where(Product.is_active == True)
    if store_id:
        query = query.where(Product.store_id == UUID(store_id))
    if category:
        query = query.where(Product.category == category)

    result = await db.execute(query)
    return result.scalars().all()


@router.get("/qr/{product_id}")
async def get_product_qr_image(product_id: str, db: AsyncSession = Depends(get_db)):
    """Serve QR code PNG for a product — what the clothing tag points to."""
    result = await db.execute(select(Product).where(Product.id == UUID(product_id)))
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    qr_bytes = generate_qr_bytes(product_id)
    return Response(content=qr_bytes, media_type="image/png")


@router.get("/{product_id}", response_model=ProductResponse)
async def get_product(product_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Product).where(Product.id == UUID(product_id)))
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product


@router.post("/scan", response_model=dict)
async def log_scan(
    data: ScanLogCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Log a QR code scan and return product details."""
    result = await db.execute(select(Product).where(Product.id == data.product_id, Product.is_active == True))
    product = result.scalar_one_or_none()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found or unavailable")

    scan_log = ScanLog(
        user_id=current_user.id,
        product_id=data.product_id,
        latitude=data.latitude,
        longitude=data.longitude,
    )
    db.add(scan_log)

    return {
        "product": ProductResponse.model_validate(product).model_dump(),
        "message": "Product scanned successfully",
        "loyalty_points_preview": product.loyalty_points_per_unit,
    }


@router.post("/", response_model=ProductResponse, status_code=201)
async def create_product(
    data: ProductCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Admin: create a product and generate its QR code."""
    store_result = await db.execute(select(Store).where(Store.id == data.store_id))
    if not store_result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Store not found")

    existing = await db.execute(select(Product).where(Product.sku == data.sku))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="SKU already exists")

    pts = data.loyalty_points_per_unit if data.loyalty_points_per_unit is not None else int(data.price // 100)

    product = Product(
        sku=data.sku,
        name=data.name,
        brand=data.brand,
        category=data.category,
        description=data.description,
        price=data.price,
        stock_quantity=data.stock_quantity,
        store_id=data.store_id,
        loyalty_points_per_unit=pts,
    )
    db.add(product)
    await db.flush()
    await db.refresh(product)

    # Store QR data URL in the product record
    qr_data_url = generate_qr_code_base64(str(product.id), product.sku)
    product.qr_code_url = qr_data_url
    await db.flush()

    return product
