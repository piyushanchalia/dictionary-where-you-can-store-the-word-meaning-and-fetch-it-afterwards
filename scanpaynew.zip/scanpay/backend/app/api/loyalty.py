from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.database import get_db
from app.models import User, LoyaltyTransaction, LoyaltyTier, TransactionType
from app.utils.schemas import LoyaltySummary, LoyaltyTransactionResponse
from app.utils.dependencies import get_current_user

router = APIRouter(prefix="/loyalty", tags=["Loyalty"])

NEXT_TIER = {
    LoyaltyTier.BRONZE: (LoyaltyTier.SILVER, 200),
    LoyaltyTier.SILVER: (LoyaltyTier.GOLD, 500),
    LoyaltyTier.GOLD: (LoyaltyTier.PLATINUM, 1000),
    LoyaltyTier.PLATINUM: (None, None),
}


@router.get("/summary", response_model=LoyaltySummary)
async def get_loyalty_summary(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    earned_result = await db.execute(
        select(func.sum(LoyaltyTransaction.points)).where(
            LoyaltyTransaction.user_id == current_user.id,
            LoyaltyTransaction.transaction_type == TransactionType.EARN,
        )
    )
    total_earned = earned_result.scalar() or 0

    redeemed_result = await db.execute(
        select(func.sum(LoyaltyTransaction.points)).where(
            LoyaltyTransaction.user_id == current_user.id,
            LoyaltyTransaction.transaction_type == TransactionType.REDEEM,
        )
    )
    total_redeemed = abs(redeemed_result.scalar() or 0)

    next_tier_info, threshold = NEXT_TIER.get(current_user.loyalty_tier, (None, None))
    points_to_next = max(0, threshold - current_user.loyalty_points) if threshold else 0

    return LoyaltySummary(
        current_points=current_user.loyalty_points,
        current_tier=current_user.loyalty_tier,
        total_earned=total_earned,
        total_redeemed=total_redeemed,
        points_to_next_tier=points_to_next,
        next_tier=next_tier_info.value if next_tier_info else None,
        cashback_value=current_user.loyalty_points * 0.5,
    )


@router.get("/history", response_model=list[LoyaltyTransactionResponse])
async def get_loyalty_history(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(LoyaltyTransaction)
        .where(LoyaltyTransaction.user_id == current_user.id)
        .order_by(LoyaltyTransaction.created_at.desc())
        .limit(50)
    )
    return result.scalars().all()
