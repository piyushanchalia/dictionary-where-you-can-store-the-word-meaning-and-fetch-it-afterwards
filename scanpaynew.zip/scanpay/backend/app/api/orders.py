import hmac
import hashlib
import random
import string
from decimal import Decimal, ROUND_HALF_UP
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from uuid import UUID
from app.database import get_db
from app.models import (
    Order, OrderItem, Product, Store, User,
    LoyaltyTransaction, LoyaltyTier, OrderStatus, TransactionType
)
from app.utils.schemas import (
    CreateOrderRequest, OrderResponse, PaymentVerifyRequest
)
from app.utils.dependencies import get_current_user
from app.config import settings

router = APIRouter(prefix="/orders", tags=["Orders"])

TAX_RATE = 0.18
POINTS_TO_RUPEE = 0.50  # 1 point = ₹0.50


def generate_order_number() -> str:
    suffix = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
    return f"SP{suffix}"


def get_tier_for_points(points: int) -> LoyaltyTier:
    if points >= 1000:
        return LoyaltyTier.PLATINUM
    if points >= 500:
        return LoyaltyTier.GOLD
    if points >= 200:
        return LoyaltyTier.SILVER
    return LoyaltyTier.BRONZE


@router.post("/", response_model=OrderResponse, status_code=201)
async def create_order(
    data: CreateOrderRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new order from cart items and initiate Razorpay payment."""
    store_result = await db.execute(select(Store).where(Store.id == data.store_id))
    store = store_result.scalar_one_or_none()
    if not store:
        raise HTTPException(status_code=404, detail="Store not found")

    # Validate redeem points
    if data.redeem_points > current_user.loyalty_points:
        raise HTTPException(status_code=400, detail="Insufficient loyalty points")

    order_items = []
    subtotal = Decimal("0.00")
    total_points_earned = 0

    for cart_item in data.items:
        prod_result = await db.execute(
            select(Product).where(Product.id == cart_item.product_id, Product.is_active == True)
        )
        product = prod_result.scalar_one_or_none()
        if not product:
            raise HTTPException(status_code=404, detail=f"Product {cart_item.product_id} not found")

        if product.stock_quantity < cart_item.quantity:
            raise HTTPException(status_code=400, detail=f"Insufficient stock for {product.name}")

        item_price = Decimal(str(product.price))
        item_subtotal = item_price * cart_item.quantity
        item_points = product.loyalty_points_per_unit * cart_item.quantity
        subtotal += item_subtotal
        total_points_earned += item_points

        order_items.append((product, cart_item.quantity, item_price, item_subtotal, item_points))

    tax_amount = (subtotal * Decimal(str(TAX_RATE))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    discount_amount = (Decimal(str(data.redeem_points)) * Decimal(str(POINTS_TO_RUPEE))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    total_amount = max(Decimal("0.00"), (subtotal + tax_amount - discount_amount).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))

    # Create Razorpay order if keys configured, else mock
    razorpay_order_id = None
    if settings.RAZORPAY_KEY_ID and settings.RAZORPAY_KEY_ID != "rzp_test_xxxxxxxxxxxxxxxx":
        import razorpay
        client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
        rz_order = client.order.create({
            "amount": int(total_amount * 100),  # paise
            "currency": "INR",
            "receipt": generate_order_number(),
        })
        razorpay_order_id = rz_order["id"]

    order = Order(
        order_number=generate_order_number(),
        user_id=current_user.id,
        store_id=store.id,
        subtotal=subtotal,
        tax_amount=tax_amount,
        discount_amount=discount_amount,
        total_amount=total_amount,
        loyalty_points_earned=total_points_earned,
        loyalty_points_redeemed=data.redeem_points,
        payment_method=data.payment_method,
        razorpay_order_id=razorpay_order_id,
    )
    db.add(order)
    await db.flush()

    for product, qty, unit_price, item_sub, item_pts in order_items:
        db.add(OrderItem(
            order_id=order.id,
            product_id=product.id,
            quantity=qty,
            unit_price=unit_price,
            subtotal=item_sub,
            loyalty_points=item_pts,
        ))
        product.stock_quantity -= qty

    await db.flush()

    result = await db.execute(
        select(Order)
        .where(Order.id == order.id)
        .options(
            selectinload(Order.items).selectinload(OrderItem.product),
            selectinload(Order.store),
        )
    )
    return result.scalar_one()


@router.post("/verify-payment", response_model=OrderResponse)
async def verify_payment(
    data: PaymentVerifyRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Verify Razorpay signature and mark order as paid."""
    result = await db.execute(
        select(Order)
        .where(Order.id == data.order_id, Order.user_id == current_user.id)
        .options(
            selectinload(Order.items).selectinload(OrderItem.product),
            selectinload(Order.store),
        )
    )
    order = result.scalar_one_or_none()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    if order.status == OrderStatus.PAID:
        return order

    # Verify Razorpay signature
    if settings.RAZORPAY_KEY_SECRET and settings.RAZORPAY_KEY_SECRET != "xxxxxxxxxxxxxxxxxxxxxxxx":
        body = f"{data.razorpay_order_id}|{data.razorpay_payment_id}"
        expected_sig = hmac.new(
            key=settings.RAZORPAY_KEY_SECRET.encode(),
            msg=body.encode(),
            digestmod=hashlib.sha256,
        ).hexdigest()
        if not hmac.compare_digest(expected_sig, data.razorpay_signature):
            raise HTTPException(status_code=400, detail="Invalid payment signature")

    order.status = OrderStatus.PAID
    order.razorpay_payment_id = data.razorpay_payment_id
    order.paid_at = datetime.now(timezone.utc)

    # Update user loyalty points
    new_balance = current_user.loyalty_points + order.loyalty_points_earned - order.loyalty_points_redeemed
    current_user.loyalty_points = max(0, new_balance)
    current_user.total_spent = Decimal(str(current_user.total_spent)) + Decimal(str(order.total_amount))
    current_user.loyalty_tier = get_tier_for_points(current_user.loyalty_points)

    db.add(LoyaltyTransaction(
        user_id=current_user.id,
        order_id=order.id,
        transaction_type=TransactionType.EARN,
        points=order.loyalty_points_earned,
        balance_after=current_user.loyalty_points,
        description=f"Points earned at {order.store.name}",
    ))

    if order.loyalty_points_redeemed > 0:
        db.add(LoyaltyTransaction(
            user_id=current_user.id,
            order_id=order.id,
            transaction_type=TransactionType.REDEEM,
            points=-order.loyalty_points_redeemed,
            balance_after=current_user.loyalty_points,
            description=f"Points redeemed at {order.store.name}",
        ))

    return order


@router.post("/{order_id}/pay-mock", response_model=OrderResponse)
async def mock_payment(
    order_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Dev/demo endpoint: mark order as paid without Razorpay."""
    return await verify_payment(
        PaymentVerifyRequest(
            razorpay_order_id="mock_order",
            razorpay_payment_id=f"mock_pay_{order_id[:8]}",
            razorpay_signature="mock_signature",
            order_id=UUID(order_id),
        ),
        current_user=current_user,
        db=db,
    )


@router.get("/", response_model=list[OrderResponse])
async def list_orders(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Order)
        .where(Order.user_id == current_user.id)
        .options(
            selectinload(Order.items).selectinload(OrderItem.product),
            selectinload(Order.store),
        )
        .order_by(Order.created_at.desc())
    )
    return result.scalars().all()


@router.get("/{order_id}", response_model=OrderResponse)
async def get_order(
    order_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(
        select(Order)
        .where(Order.id == UUID(order_id), Order.user_id == current_user.id)
        .options(
            selectinload(Order.items).selectinload(OrderItem.product),
            selectinload(Order.store),
        )
    )
    order = result.scalar_one_or_none()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return order
