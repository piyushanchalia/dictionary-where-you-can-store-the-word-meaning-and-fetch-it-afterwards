from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db
from app.models import Store, User
from app.utils.schemas import StoreResponse, NearestStoreResponse, StoreDetectRequest
from app.utils.dependencies import get_current_user
from app.utils.geo import find_nearest_store, is_within_store

router = APIRouter(prefix="/stores", tags=["Stores"])


@router.get("/", response_model=list[StoreResponse])
async def list_stores(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Store).where(Store.is_active == True))
    return result.scalars().all()


@router.get("/{store_id}", response_model=StoreResponse)
async def get_store(store_id: str, db: AsyncSession = Depends(get_db)):
    from uuid import UUID
    result = await db.execute(select(Store).where(Store.id == UUID(store_id)))
    store = result.scalar_one_or_none()
    if not store:
        raise HTTPException(status_code=404, detail="Store not found")
    return store


@router.post("/detect", response_model=NearestStoreResponse)
async def detect_store(
    location: StoreDetectRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Find the nearest store based on user coordinates."""
    result = await db.execute(select(Store).where(Store.is_active == True))
    stores = result.scalars().all()

    if not stores:
        raise HTTPException(status_code=404, detail="No stores available")

    nearest = find_nearest_store(location.latitude, location.longitude, stores)
    if not nearest:
        raise HTTPException(status_code=404, detail="No stores found")

    store = nearest["store"]
    within_range = is_within_store(
        location.latitude, location.longitude,
        store.latitude, store.longitude,
        store.radius_meters,
    )

    return NearestStoreResponse(
        store=StoreResponse.model_validate(store),
        distance_meters=nearest["distance_meters"],
        is_within_range=within_range,
    )
