"""
Seed the database with stores and products.
Run: python seed.py
"""
import asyncio
import sys
import os
from dotenv import load_dotenv

# Load .env before importing app config
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

sys.path.insert(0, os.path.dirname(__file__))

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from app.config import settings
from app.models import Store, Product, Base

engine = create_async_engine(settings.DATABASE_URL)
AsyncSessionLocal = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

STORES = [
    {
        "name": "Zara Premium",
        "address": "22 Park Street",
        "city": "Kolkata",
        "latitude": 22.5513,
        "longitude": 88.3515,
        "radius_meters": 150,
        "category": "Fashion",
    },
    {
        "name": "H&M Central",
        "address": "South City Mall, Prince Anwar Shah Road",
        "city": "Kolkata",
        "latitude": 22.4955,
        "longitude": 88.3628,
        "radius_meters": 200,
        "category": "Casual",
    },
    {
        "name": "Shoppers Stop",
        "address": "Lindsay Street, New Market",
        "city": "Kolkata",
        "latitude": 22.5574,
        "longitude": 88.3510,
        "radius_meters": 100,
        "category": "Multi-brand",
    },
]

PRODUCTS_TEMPLATE = [
    # Zara
    {"sku": "ZR-OXF-001", "name": "Premium Oxford Shirt", "brand": "Zara", "category": "Shirts", "price": 2499, "stock": 45, "store_idx": 0},
    {"sku": "ZR-CHN-002", "name": "Slim Fit Chinos", "brand": "Zara", "category": "Bottoms", "price": 3299, "stock": 30, "store_idx": 0},
    {"sku": "ZR-DRS-003", "name": "Floral Summer Dress", "brand": "Zara", "category": "Dresses", "price": 2899, "stock": 20, "store_idx": 0},
    {"sku": "ZR-BLZ-004", "name": "Structured Blazer", "brand": "Zara", "category": "Outerwear", "price": 6999, "stock": 15, "store_idx": 0},
    # H&M
    {"sku": "HM-TEE-001", "name": "Casual Graphic Tee", "brand": "H&M", "category": "Tops", "price": 799, "stock": 80, "store_idx": 1},
    {"sku": "HM-DNM-002", "name": "Denim Jacket", "brand": "H&M", "category": "Outerwear", "price": 3999, "stock": 25, "store_idx": 1},
    {"sku": "HM-SWT-003", "name": "Wool Blend Sweater", "brand": "H&M", "category": "Tops", "price": 2199, "stock": 35, "store_idx": 1},
    {"sku": "HM-JGG-004", "name": "Slim Joggers", "brand": "H&M", "category": "Bottoms", "price": 1299, "stock": 60, "store_idx": 1},
    # Shoppers Stop
    {"sku": "SS-KRT-001", "name": "Linen Kurta Set", "brand": "Shoppers Stop", "category": "Ethnic", "price": 3499, "stock": 40, "store_idx": 2},
    {"sku": "SS-SAR-002", "name": "Silk Blend Saree", "brand": "Shoppers Stop", "category": "Ethnic", "price": 4999, "stock": 18, "store_idx": 2},
    {"sku": "SS-DNM-003", "name": "Straight Jeans", "brand": "Shoppers Stop", "category": "Bottoms", "price": 2199, "stock": 50, "store_idx": 2},
]


async def seed():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with AsyncSessionLocal() as session:
        from sqlalchemy import select

        existing = await session.execute(select(Store).limit(1))
        if existing.scalar_one_or_none():
            print("Database already seeded. Skipping.")
            return

        store_ids = []
        for s in STORES:
            store = Store(
                name=s["name"],
                address=s["address"],
                city=s["city"],
                latitude=s["latitude"],
                longitude=s["longitude"],
                radius_meters=s["radius_meters"],
                category=s["category"],
            )
            session.add(store)
            await session.flush()
            store_ids.append(store.id)
            print(f"✅ Created store: {s['name']}")

        for p in PRODUCTS_TEMPLATE:
            pts = int(p["price"] // 100)
            product = Product(
                sku=p["sku"],
                name=p["name"],
                brand=p["brand"],
                category=p["category"],
                price=p["price"],
                stock_quantity=p["stock"],
                store_id=store_ids[p["store_idx"]],
                loyalty_points_per_unit=pts,
            )
            session.add(product)
            await session.flush()

            from app.utils.qr import generate_qr_code_base64
            product.qr_code_url = generate_qr_code_base64(str(product.id), product.sku)
            print(f"  📦 Created product: {p['name']} | QR generated")

        await session.commit()
        print("\n🎉 Database seeded successfully!")
        print(f"   {len(STORES)} stores, {len(PRODUCTS_TEMPLATE)} products with QR codes")


if __name__ == "__main__":
    asyncio.run(seed())
